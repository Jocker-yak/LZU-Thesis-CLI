(() => {
  // src/lib/protocol.js
  var PORTAL_ORIGIN = "http://202.201.7.17";
  var SEARCH_URL = PORTAL_ORIGIN + "/simpsearch.action?ffieldname=xkcode&ffieldkey=07*&dbid=72";
  function base64ToBytes(text) {
    const clean = String(text).replace(/[^A-Za-z0-9+/=]/g, "").replace(/=+$/, "");
    if (!clean) return new Uint8Array(0);
    const padded = clean + "=".repeat((4 - clean.length % 4) % 4);
    const bin = atob(padded);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function unquote(text) {
    const src = String(text);
    const bytes = [];
    for (let i = 0; i < src.length; i++) {
      const ch = src[i];
      if (ch === "%" && /^[0-9a-fA-F]{2}$/.test(src.slice(i + 1, i + 3))) {
        bytes.push(parseInt(src.slice(i + 1, i + 3), 16));
        i += 2;
      } else {
        const code = src.charCodeAt(i);
        if (code < 128) {
          bytes.push(code);
        } else {
          for (const b of new TextEncoder().encode(src[i])) bytes.push(b);
        }
      }
    }
    return new TextDecoder("utf-8", { fatal: false }).decode(new Uint8Array(bytes));
  }
  function extractToken(input) {
    const text = String(input || "").trim();
    if (!text) return "";
    const m = /personaliiifServlet\?path=([A-Za-z0-9+/=%]+)/.exec(text);
    if (m) return m[1];
    if (/^[A-Za-z0-9+/=%]{20,}$/.test(text)) return text;
    return "";
  }
  function decodeToken(token) {
    const raw = String(token || "").trim();
    if (raw.length < 6) throw new Error("\u4EE4\u724C\u592A\u77ED\uFF0C\u65E0\u6CD5\u89E3\u6790");
    const prefix = raw.slice(0, 5);
    const body = raw.slice(5).replace(/%3[dD]/g, "=");
    let payload;
    try {
      payload = new TextDecoder("utf-8", { fatal: false }).decode(base64ToBytes(body));
    } catch (err) {
      throw new Error(`\u4EE4\u724C base64 \u89E3\u7801\u5931\u8D25\uFF1A${err.message}`);
    }
    const parts = payload.split("&");
    const path = unquote(parts.shift() || "");
    const fields = /* @__PURE__ */ Object.create(null);
    for (const kv of parts) {
      const idx = kv.indexOf("=");
      if (idx > 0) fields[kv.slice(0, idx)] = unquote(kv.slice(idx + 1));
    }
    const num = (v) => {
      const n = Number.parseInt(v, 10);
      return Number.isFinite(n) ? n : null;
    };
    const storeName = path.split(/[\\/]/).pop() || path;
    return {
      prefix,
      path,
      storeName,
      startpage: num(fields.startpage),
      endpage: num(fields.endpage),
      down: num(fields.down),
      watermark: fields.watermark || "",
      filename: fields.filename || "",
      infoname: fields.infoname || "",
      fields: Object.freeze({ ...fields })
    };
  }

  // src/lib/ext.js
  var api = globalThis.browser ?? globalThis.chrome;
  var navUserAgent = (() => {
    try {
      return String(typeof navigator !== "undefined" && navigator.userAgent || "");
    } catch {
      return "";
    }
  })();
  var isFirefox = typeof (api && api.runtime && api.runtime.getBrowserInfo) === "function" || navUserAgent.includes("Firefox/");

  // src/ui/shared-view.js
  var PHASES = {
    queued: "\u6392\u961F\u4E2D",
    resolve: "\u6253\u5F00\u9605\u8BFB\u5668",
    meta: "\u8BFB\u53D6\u6587\u6863\u4FE1\u606F",
    urls: "\u83B7\u53D6\u9875\u9762\u5730\u5740",
    pages: "\u4E0B\u8F7D\u9875\u9762",
    build: "\u5408\u6210 PDF",
    save: "\u4FDD\u5B58\u6587\u4EF6",
    done: "\u5B8C\u6210",
    error: "\u5931\u8D25",
    cancelled: "\u5DF2\u53D6\u6D88",
    interrupted: "\u5DF2\u4E2D\u65AD"
  };
  var COMPACT_TABS = [
    ["search", "\u68C0\u7D22"],
    ["token", "\u4EE4\u724C"],
    ["link", "\u76F4\u94FE"]
  ];
  var FULL_TABS = [
    ["search", "\u68C0\u7D22"],
    ["tasks", "\u4EFB\u52A1"],
    ["history", "\u5386\u53F2"],
    ["settings", "\u8BBE\u7F6E"],
    ["log", "\u65E5\u5FD7"],
    ["help", "\u5E2E\u52A9"]
  ];
  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value === null || value === void 0 || value === false) continue;
      if (key === "class") node.className = value;
      else if (key === "text") node.textContent = value;
      else if (key === "onClick") node.addEventListener("click", value);
      else if (key === "onInput") node.addEventListener("input", value);
      else if (key === "onChange") node.addEventListener("change", value);
      else if (key === "onSubmit") node.addEventListener("submit", value);
      else node.setAttribute(key, value === true ? "" : String(value));
    }
    for (const child of [].concat(children)) {
      if (child === null || child === void 0 || child === false) continue;
      node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
    }
    return node;
  }
  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
  }
  async function call(type, extra = {}) {
    let reply;
    try {
      reply = await api.runtime.sendMessage({ type, ...extra });
    } catch (err) {
      throw new Error(`\u540E\u53F0\u6CA1\u6709\u54CD\u5E94\uFF08${err && err.message}\uFF09`);
    }
    if (!reply) throw new Error("\u540E\u53F0\u6CA1\u6709\u54CD\u5E94");
    if (reply.ok === false) throw new Error(reply.error || "\u64CD\u4F5C\u5931\u8D25");
    return reply;
  }
  function fmtTime(ts) {
    if (!ts) return "";
    const d = new Date(ts);
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getMonth() + 1}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }
  function fmtSize(bytes) {
    if (!bytes) return "";
    if (bytes > 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    return `${Math.round(bytes / 1024)} KB`;
  }
  function phaseText(task) {
    const key = task.phase || task.status;
    return PHASES[key] || key || "";
  }
  function mountView(root, { compact = false } = {}) {
    const TAB_LIST = compact ? COMPACT_TABS : FULL_TABS;
    const state = {
      compact,
      tab: TAB_LIST[0][0],
      settings: null,
      lastKeyword: "",
      tasks: [],
      rows: [],
      rowState: /* @__PURE__ */ new Map(),
      // rowKey → {busy, fid, status, error}
      keyword: "",
      probe: null,
      toastTimer: null
    };
    const dot = el("span", { class: "status-dot", title: "\u6B63\u5728\u68C0\u6D4B\u95E8\u6237/\u9605\u8BFB\u5668\u8FDE\u901A\u6027\u2026" });
    const topbar = el("header", { class: "topbar" }, [
      el("div", { class: "brand" }, [
        el("span", { class: "logo", text: "L" }),
        el("div", {}, [
          el("h1", { text: "\u5170\u5927\u8BBA\u6587\u5168\u6587\u52A9\u624B" }),
          el("div", { class: "sub", text: fmtVersion() })
        ])
      ]),
      el("span", { class: "spacer" }),
      dot,
      compact ? el("button", { text: "\u5DE5\u4F5C\u53F0", onClick: openWorkspace }) : el("button", { text: "\u91CD\u65B0\u68C0\u6D4B", onClick: () => probe(true) })
    ]);
    const tabs = el("nav", { class: "tabs" });
    const view = el("main", { class: "view" });
    const toast = el("div", { class: "toast" });
    root.textContent = "";
    root.appendChild(el("div", { class: "app" }, [topbar, tabs, view]));
    root.appendChild(toast);
    const tabButtons = /* @__PURE__ */ new Map();
    for (const [id, label] of TAB_LIST) {
      const btn = el("button", { text: label, onClick: () => showTab(id) });
      tabButtons.set(id, btn);
      tabs.appendChild(btn);
    }
    function showTab(id) {
      state.tab = id;
      for (const [key, btn] of tabButtons) btn.classList.toggle("active", key === id);
      render();
    }
    function showToast(message, isError = false) {
      toast.textContent = message;
      toast.className = `toast show${isError ? " error" : ""}`;
      clearTimeout(state.toastTimer);
      state.toastTimer = setTimeout(() => {
        toast.className = "toast";
      }, 3200);
    }
    async function openWorkspace() {
      try {
        await call("open-app", { hash: "#/workspace" });
        window.close();
      } catch (err) {
        showToast(err.message, true);
      }
    }
    async function probe(refresh = false) {
      dot.className = "status-dot";
      dot.title = "\u68C0\u6D4B\u4E2D\u2026";
      try {
        const reply = await call("probe");
        state.probe = reply;
        const portalOk = reply.portal && reply.portal.ok === true;
        const readerOk = reply.reader && reply.reader.ok === true;
        const skipped = reply.portal && reply.portal.ok === null;
        dot.className = `status-dot ${portalOk ? "ok" : skipped ? "unknown" : "bad"}`;
        dot.title = skipped ? `\u95E8\u6237 202.201.7.17 / \u9605\u8BFB\u5668 202.201.7.29\uFF1A${reply.portal.note || "\u9700\u5148\u6253\u5F00\u7AD9\u70B9\u9875\u9762"}` : `\u95E8\u6237 202.201.7.17\uFF1A${portalOk ? `\u53EF\u8FBE ${reply.portal.status || 200}` : "\u4E0D\u53EF\u8FBE\uFF08\u6821\u5185\u7F51/\u767B\u5F55\uFF09"}\uFF1B\u9605\u8BFB\u5668 202.201.7.29\uFF1A${readerOk ? "\u53EF\u8FBE" : "\u4E0D\u53EF\u8FBE"}`;
        if (refresh) {
          if (skipped) showToast(reply.portal.note || "\u6253\u5F00\u95E8\u6237\u9875\u9762\u540E\u5373\u53EF\u4F7F\u7528", false);
          else showToast(portalOk ? "\u95E8\u6237\u53EF\u8FBE" : "\u95E8\u6237\u4E0D\u53EF\u8FBE\uFF1A\u8BF7\u786E\u8BA4\u6821\u5185\u7F51\u4E0E\u767B\u5F55\u72B6\u6001", !portalOk);
        }
      } catch (err) {
        dot.className = "status-dot bad";
        dot.title = err.message;
      }
      if (state.tab === "search") render();
    }
    function fmtVersion() {
      try {
        const manifest = api.runtime.getManifest();
        return `v${manifest.version} \xB7 \u6821\u5185\u7F51 \xB7 \u590D\u7528\u5DF2\u767B\u5F55\u4F1A\u8BDD`;
      } catch {
        return "\u6821\u5185\u7F51 \xB7 \u590D\u7528\u5DF2\u767B\u5F55\u4F1A\u8BDD";
      }
    }
    api.runtime.onMessage.addListener((message) => {
      if (!message || typeof message.type !== "string") return false;
      if (message.type === "task-update" && message.task) {
        mergeTask(message.task);
        if (state.tab === "tasks") render();
        else if (state.tab === "search") refreshRowStatuses();
      } else if (message.type === "row-link") {
        applyRowLink(message);
      } else if (message.type === "row-fid") {
        applyRowFid(message);
      } else if (message.type === "row-fid-done") {
        showToast(`fid \u89E3\u6790\u5B8C\u6210\uFF08${message.count} \u6761\uFF09`);
      }
      return false;
    });
    function mergeTask(task) {
      const index = state.tasks.findIndex((t) => t.id === task.id);
      if (index >= 0) state.tasks[index] = { ...state.tasks[index], ...task };
      else state.tasks.unshift(task);
      state.tasks = state.tasks.slice(0, 30);
    }
    function render() {
      clear(view);
      if (state.tab === "search") renderSearch();
      else if (state.tab === "token") renderToken();
      else if (state.tab === "link") renderLink();
      else if (state.tab === "tasks") renderTasks();
      else if (state.tab === "history") renderHistory();
      else if (state.tab === "settings") renderSettings();
      else if (state.tab === "log") renderLog();
      else if (state.tab === "help") renderHelp();
    }
    let rowsWrap = null;
    function renderSearch() {
      const input = el("input", {
        type: "text",
        placeholder: "\u4F5C\u8005\u59D3\u540D / \u9898\u540D\u5173\u952E\u8BCD\uFF0C\u5982\uFF1A\u4FAF\u6276\u6C5F",
        value: state.keyword || "",
        onInput: (e) => {
          state.keyword = e.target.value;
        }
      });
      const submit = el("button", { class: "primary", type: "submit", text: "\u68C0\u7D22" });
      const form = el("form", {
        class: "form-row",
        onSubmit: async (event) => {
          event.preventDefault();
          await doSearch(input.value.trim(), submit);
        }
      }, [input, submit]);
      const probeSkipped = state.probe && state.probe.portal && state.probe.portal.ok === null;
      const probeFailed = state.probe && state.probe.portal && state.probe.portal.ok === false;
      const probeHint = el("div", {
        class: `hint${probeFailed ? " error" : ""}`,
        text: probeFailed ? "\u95E8\u6237\u5F53\u524D\u4E0D\u53EF\u8FBE\uFF1A\u8BF7\u8FDE\u6821\u5185\u7F51\u5E76\u5728\u6D4F\u89C8\u5668\u91CC\u767B\u5F55\u95E8\u6237\u540E\u518D\u8BD5\u3002" : probeSkipped ? state.probe.portal.note || "Firefox \u9700\u5148\u6253\u5F00\u95E8\u6237\u9875\u9762\uFF0C\u4E4B\u540E\u4F1A\u81EA\u52A8\u4F7F\u7528\u9875\u9762\u5185\u901A\u9053\u3002" : "\u68C0\u7D22\u8D70\u95E8\u6237 xkcode 07* \u5E93\uFF1B\u53EA\u8BFB\u68C0\u7D22\uFF0C\u4E0D\u6539\u53D8\u4EFB\u4F55\u6570\u636E\u3002"
      });
      const toolbar = el("div", { class: "toolbar" }, [
        el("button", { text: "\u89E3\u6790\u5168\u90E8 fid", onClick: () => resolveAllFids() }),
        el("span", { class: "spacer" }),
        el("span", { class: "hint", text: state.lastKeyword ? `\u4E0A\u6B21\uFF1A${state.lastKeyword}` : "" })
      ]);
      rowsWrap = el("div", { class: "rows" });
      view.appendChild(el("h2", { text: "\u68C0\u7D22\u8BBA\u6587" }));
      view.appendChild(form);
      view.appendChild(probeHint);
      view.appendChild(toolbar);
      view.appendChild(rowsWrap);
      renderRows();
      if (state.rows.length === 0) {
        rowsWrap.appendChild(el("div", { class: "empty", text: "\u8FD8\u6CA1\u6709\u7ED3\u679C\u3002\u8F93\u5165\u5173\u952E\u8BCD\u540E\u56DE\u8F66\u6216\u70B9\u300C\u68C0\u7D22\u300D\u3002" }));
      }
    }
    function renderRows() {
      if (!rowsWrap) return;
      clear(rowsWrap);
      if (!state.rows.length) return;
      for (const row of state.rows) rowsWrap.appendChild(buildRow(row));
    }
    function refreshRowStatuses() {
      if (!rowsWrap) return;
      renderRows();
    }
    function rowKey(row) {
      return `${row.id1}/${row.id2}`;
    }
    function buildRow(row) {
      const key = rowKey(row);
      const rs = state.rowState.get(key) || {};
      const statusClass = rs.error ? "err" : rs.fid ? "ok" : "";
      const statusText = rs.error || (rs.fid ? `fid ${rs.fid.slice(0, 10)}\u2026` : rs.status || "\u672A\u89E3\u6790 fid");
      return el("div", { class: "row" }, [
        el("div", { class: "row-title", text: row.title || "(\u65E0\u6807\u9898)" }),
        el("div", { class: "row-meta", text: `id1 ${String(row.id1).slice(0, 12)}\u2026 \xB7 ${row.link ? "\u6709\u5168\u6587\u5165\u53E3" : "\u65E0\u5168\u6587\u5165\u53E3"}` }),
        el("div", { class: "row-actions" }, [
          el("button", {
            class: "primary",
            text: rs.busy ? "\u5904\u7406\u4E2D\u2026" : "\u4E0B\u8F7D\u5168\u6587",
            disabled: !row.link || rs.busy ? true : null,
            onClick: () => downloadRow(row)
          }),
          el("button", {
            text: "\u4EC5\u89E3\u6790 fid",
            disabled: rs.busy ? true : null,
            onClick: () => resolveRow(row)
          }),
          row.link ? el("button", { class: "link", text: "\u6253\u5F00\u5165\u53E3", onClick: () => openUrl(row.link) }) : null
        ]),
        el("div", { class: `row-status ${statusClass}`.trim(), text: statusText })
      ]);
    }
    async function doSearch(keyword, button) {
      if (!keyword) {
        showToast("\u8BF7\u8F93\u5165\u68C0\u7D22\u8BCD", true);
        return;
      }
      state.keyword = keyword;
      button.disabled = true;
      button.textContent = "\u68C0\u7D22\u4E2D\u2026";
      try {
        const reply = await call("search", { keyword });
        state.rows = reply.rows || [];
        state.lastKeyword = reply.keyword || keyword;
        state.rowState = /* @__PURE__ */ new Map();
        if (state.rows.length === 0) showToast("\u6CA1\u6709\u68C0\u7D22\u5230\u8BB0\u5F55");
        else showToast(`\u5171 ${state.rows.length} \u6761${reply.total ? `\uFF08\u95E8\u6237\u6807\u79F0 ${reply.total} \u6761\uFF09` : ""}`);
        render();
      } catch (err) {
        showToast(err.message, true);
      } finally {
        button.disabled = false;
        button.textContent = "\u68C0\u7D22";
      }
    }
    async function resolveAllFids() {
      if (!state.rows.length) {
        showToast("\u8BF7\u5148\u68C0\u7D22", true);
        return;
      }
      try {
        await call("resolve-fids", { rows: state.rows });
        showToast("\u5F00\u59CB\u540E\u53F0\u89E3\u6790 fid\u2026");
      } catch (err) {
        showToast(err.message, true);
      }
    }
    function applyRowLink(message) {
      const row = state.rows.find((r) => r.id1 === message.id1 && r.id2 === message.id2);
      if (!row) return;
      if (message.link) row.link = message.link;
      if (state.tab === "search") renderRows();
    }
    function applyRowFid(message) {
      if (!message || !message.id1) return;
      const key = `${message.id1}/${message.id2}`;
      const prev = state.rowState.get(key) || {};
      state.rowState.set(key, {
        ...prev,
        busy: false,
        fid: message.fid || null,
        error: message.error || null,
        status: message.fid ? `fid ${message.fid.slice(0, 10)}\u2026` : message.error || "\u672A\u89E3\u6790 fid"
      });
      if (state.tab === "search") renderRows();
    }
    async function resolveRow(row) {
      const key = rowKey(row);
      state.rowState.set(key, { ...state.rowState.get(key) || {}, busy: true, status: "\u89E3\u6790 fid\u2026", error: null });
      renderRows();
      try {
        const reply = await call("resolve-link", { link: row.link });
        state.rowState.set(key, { busy: false, fid: reply.fid, status: `fid ${reply.fid.slice(0, 10)}\u2026`, error: null });
        mergeTask(await start({ fid: reply.fid }));
      } catch (err) {
        state.rowState.set(key, { busy: false, error: err.message, fid: null });
      }
      if (state.tab === "search") renderRows();
    }
    async function downloadRow(row) {
      const key = rowKey(row);
      const rs = state.rowState.get(key) || {};
      state.rowState.set(key, { ...rs, busy: true, status: "\u51C6\u5907\u4E0B\u8F7D\u2026", error: null });
      renderRows();
      try {
        if (rs.fid) {
          mergeTask(await start({ fid: rs.fid }));
          state.rowState.set(key, { ...rs, busy: false, status: "\u5DF2\u52A0\u5165\u4E0B\u8F7D", error: null });
        } else {
          const reply = await call("resolve-link", { link: row.link });
          state.rowState.set(key, { busy: false, fid: reply.fid, status: `fid ${reply.fid.slice(0, 10)}\u2026`, error: null });
          mergeTask(await start({ fid: reply.fid }));
        }
        if (state.compact) showToast("\u5DF2\u5F00\u59CB\u4E0B\u8F7D\uFF0C\u8FDB\u5EA6\u89C1\u4EFB\u52A1\u9875/\u6D6E\u5C42");
      } catch (err) {
        state.rowState.set(key, { busy: false, error: err.message, fid: rs.fid || null });
        showToast(err.message, true);
      }
      if (state.tab === "search") renderRows();
    }
    async function start(payload) {
      const reply = await call("start", payload);
      return reply.task;
    }
    function renderToken() {
      const textarea = el("textarea", {
        placeholder: "\u7C98\u8D34\u4EE4\u724C\uFF0C\u6216\u542B personaliiifServlet?path=\u2026 \u7684\u94FE\u63A5/HTML \u7247\u6BB5",
        onInput: () => {
          preview();
        }
      });
      const previewBox = el("div", { class: "card" });
      function preview() {
        clear(previewBox);
        const token = extractToken(textarea.value);
        if (!token) {
          previewBox.appendChild(el("div", { class: "hint", text: "\u8FD8\u6CA1\u8BC6\u522B\u5230\u4EE4\u724C\uFF08\u6709\u6548\u4EE4\u724C\u81F3\u5C11 20 \u4E2A\u5B57\u7B26\uFF09\u3002" }));
          return;
        }
        let info;
        try {
          info = decodeToken(token);
        } catch (err) {
          previewBox.appendChild(el("div", { class: "hint error", text: `\u4EE4\u724C\u89E3\u6790\u5931\u8D25\uFF1A${err.message}` }));
          return;
        }
        previewBox.appendChild(el("dl", { class: "kv" }, [
          el("dt", { text: "\u9898\u540D" }),
          el("dd", { text: info.infoname || "(\u7A7A)" }),
          el("dt", { text: "\u6587\u4EF6\u540D" }),
          el("dd", { text: info.filename || "(\u7A7A)" }),
          el("dt", { text: "\u9875\u6570" }),
          el("dd", { text: info.endpage ? `1 \u2013 ${info.endpage}` : "\u672A\u77E5" }),
          el("dt", { text: "\u5B58\u50A8\u8DEF\u5F84" }),
          el("dd", { text: info.path }),
          el("dt", { text: "\u4EE4\u724C\u957F\u5EA6" }),
          el("dd", { text: `${token.length} \u5B57\u7B26\uFF08\u524D\u7F00 ${info.prefix}\uFF09` })
        ]));
      }
      const download = el("button", {
        class: "primary",
        text: "\u5F00\u59CB\u4E0B\u8F7D",
        onClick: async () => {
          const token = extractToken(textarea.value);
          if (!token) {
            showToast("\u6CA1\u8BC6\u522B\u5230\u4EE4\u724C", true);
            return;
          }
          try {
            const task = await start({ token });
            mergeTask(task);
            showToast("\u5DF2\u5F00\u59CB\u4E0B\u8F7D\uFF0C\u53EF\u5728\u5DE5\u4F5C\u53F0\u67E5\u770B\u8FDB\u5EA6");
          } catch (err) {
            showToast(err.message, true);
          }
        }
      });
      view.appendChild(el("h2", { text: "\u7528\u4EE4\u724C\u4E0B\u8F7D" }));
      view.appendChild(el("div", { class: "hint", text: "\u4EE4\u724C\u6709\u6548\u671F\u5F88\u77ED\uFF08\u51E0\u5206\u949F\u5230\u51E0\u5341\u5206\u949F\uFF09\uFF0C\u7531\u95E8\u6237 docinfo \u9875\u7684 onlinePDF \u5165\u53E3\u751F\u6210\u3002" }));
      view.appendChild(textarea);
      view.appendChild(el("div", { class: "toolbar" }, [download]));
      view.appendChild(previewBox);
      preview();
    }
    function renderLink() {
      const textarea = el("textarea", {
        placeholder: "\u7C98\u8D34 onlinePDF \u94FE\u63A5\uFF08http://202.201.7.17/onlinePDF?dbid=72&objid=\u2026&state=free&flag=online\uFF09"
      });
      const download = el("button", {
        class: "primary",
        text: "\u5F00\u59CB\u4E0B\u8F7D",
        onClick: async () => {
          const link = textarea.value.trim();
          if (!link) {
            showToast("\u8BF7\u7C98\u8D34\u94FE\u63A5", true);
            return;
          }
          try {
            const task = await start({ link });
            mergeTask(task);
            showToast("\u5DF2\u5F00\u59CB\u4E0B\u8F7D\uFF0C\u53EF\u5728\u5DE5\u4F5C\u53F0\u67E5\u770B\u8FDB\u5EA6");
          } catch (err) {
            showToast(err.message, true);
          }
        }
      });
      view.appendChild(el("h2", { text: "\u7528\u5168\u6587\u94FE\u63A5\u4E0B\u8F7D" }));
      view.appendChild(el("div", { class: "hint", text: "\u5728\u95E8\u6237\u8BBA\u6587\u8BE6\u60C5\u9875\u53F3\u952E\u590D\u5236 onlinePDF \u94FE\u63A5\u5373\u53EF\uFF1B\u63D2\u4EF6\u4F1A\u7528\u5F53\u524D\u6D4F\u89C8\u5668\u4F1A\u8BDD\u6253\u5F00\u5B83\u5E76\u8BC6\u522B fid\u3002" }));
      view.appendChild(textarea);
      view.appendChild(el("div", { class: "toolbar" }, [download]));
      view.appendChild(el("div", { class: "card" }, [
        el("div", { class: "hint", text: "\u63D0\u793A\uFF1A\u4E5F\u53EF\u4EE5\u5728\u95E8\u6237\u300C\u67E5\u770B\u8BBA\u6587\u4FE1\u606F\u300D\u9875\u6216\u9605\u8BFB\u5668\u9875\u4E0A\u76F4\u63A5\u7528\u53F3\u4E0B\u89D2\u6D6E\u5C42\u6309\u94AE\u3002" })
      ]));
    }
    function renderTasks() {
      view.appendChild(el("div", { class: "toolbar" }, [
        el("h2", { text: "\u4E0B\u8F7D\u4EFB\u52A1" }),
        el("span", { class: "spacer" }),
        el("button", {
          text: "\u5237\u65B0",
          onClick: async () => {
            try {
              const reply = await call("list-tasks");
              state.tasks = reply.tasks || [];
              render();
            } catch (err) {
              showToast(err.message, true);
            }
          }
        })
      ]));
      const list = el("div", { class: "rows" });
      if (!state.tasks.length) list.appendChild(el("div", { class: "empty", text: "\u6682\u65E0\u4EFB\u52A1\u3002\u53BB\u300C\u68C0\u7D22\u300D\u6216\u300C\u4EE4\u724C\u300D\u9875\u53D1\u8D77\u4E00\u4E2A\u4E0B\u8F7D\u3002" }));
      for (const task of state.tasks) {
        const done = task.status === "done";
        const failed = task.status === "error" || task.status === "interrupted";
        const list$ = el("div", { class: "row" }, [
          el("div", { class: "row-title", text: task.title || task.filename || task.fid || "(\u672A\u77E5\u6587\u6863)" }),
          el("div", { class: "row-meta", text: `${phaseText(task)}${task.total ? ` \xB7 ${task.done || 0}/${task.total} \u9875` : ""}${task.filename ? ` \xB7 ${task.filename}` : ""}` }),
          el("div", { class: `bar${done ? " done" : failed ? " err" : ""}`.trim() }, [
            el("i", { style: `width:${task.total ? Math.min(100, Math.round((task.done || 0) / task.total * 100)) : 0}%` })
          ]),
          el("div", { class: "row-actions" }, [
            el("span", {
              class: `row-status ${done ? "ok" : failed ? "err" : ""}`.trim(),
              text: task.status === "running" ? task.msg || "\u8FDB\u884C\u4E2D\u2026" : task.error || task.msg || task.status
            }),
            task.status === "running" ? el("button", { class: "danger", text: "\u53D6\u6D88", onClick: () => cancelTask(task.id) }) : null
          ])
        ]);
        list.appendChild(list$);
      }
      view.appendChild(list);
      if (!state.tasks.length) return;
      call("list-tasks").then((reply) => {
        if (state.tab === "tasks") {
          state.tasks = reply.tasks || [];
          render();
        }
      }).catch(() => {
      });
    }
    async function cancelTask(id) {
      try {
        await call("cancel-task", { id });
        showToast("\u5DF2\u8BF7\u6C42\u53D6\u6D88");
      } catch (err) {
        showToast(err.message, true);
      }
    }
    function renderHistory() {
      const list = el("div", { class: "list" });
      view.appendChild(el("div", { class: "toolbar" }, [
        el("h2", { text: "\u4E0B\u8F7D\u5386\u53F2" }),
        el("span", { class: "spacer" }),
        el("button", {
          class: "danger",
          text: "\u6E05\u7A7A",
          onClick: async () => {
            try {
              await call("history:clear");
              render();
            } catch (err) {
              showToast(err.message, true);
            }
          }
        })
      ]));
      view.appendChild(list);
      list.appendChild(el("div", { class: "empty", text: "\u52A0\u8F7D\u4E2D\u2026" }));
      call("history:get").then((reply) => {
        clear(list);
        const entries = reply.entries || [];
        if (!entries.length) {
          list.appendChild(el("div", { class: "empty", text: "\u8FD8\u6CA1\u6709\u4E0B\u8F7D\u8BB0\u5F55\u3002" }));
          return;
        }
        for (const entry of entries) {
          list.appendChild(el("div", { class: "list-item" }, [
            el("span", { class: "t", text: fmtTime(entry.endedAt) }),
            el("span", { class: "m", text: `${entry.title || entry.fid || ""}${entry.filename ? ` \xB7 ${entry.filename}` : ""}${entry.pageCount ? ` \xB7 ${entry.pageCount} \u9875` : ""}` }),
            el("span", { class: `lv ${entry.status === "done" ? "" : "error"}`.trim(), text: entry.status === "done" ? fmtSize(entry.bytes) || "\u5B8C\u6210" : "\u5931\u8D25" })
          ]));
        }
      }).catch((err) => {
        clear(list);
        list.appendChild(el("div", { class: "hint error", text: err.message }));
      });
    }
    function renderSettings() {
      view.appendChild(el("h2", { text: "\u8BBE\u7F6E" }));
      const box = el("div", { class: "settings" });
      view.appendChild(box);
      box.appendChild(el("div", { class: "empty", text: "\u52A0\u8F7D\u4E2D\u2026" }));
      call("settings:get").then((reply) => {
        clear(box);
        const settings = reply.settings || {};
        const fields = [];
        const add = (label, control, hintText) => {
          fields.push(el("div", { class: "field" }, [el("label", { text: label }), control, hintText ? el("div", { class: "hint", text: hintText }) : null]));
        };
        const transport = el("select", {}, [
          el("option", { value: "auto", text: "\u81EA\u52A8\uFF08\u4F18\u5148\u9875\u9762\u5185\u6865\u63A5\uFF0C\u5931\u8D25\u9000\u56DE\u540E\u53F0\u8BF7\u6C42\uFF09" }),
          el("option", { value: "bridge", text: "\u53EA\u7528\u9875\u9762\u5185\u6865\u63A5\uFF08\u4F1A\u8BDD\u6700\u53EF\u9760\uFF09" }),
          el("option", { value: "bg", text: "\u53EA\u7528\u540E\u53F0 fetch\uFF08\u4E0D\u63A8\u8350\uFF09" })
        ]);
        transport.value = settings.transport || "auto";
        add("\u4F20\u8F93\u65B9\u5F0F", transport, ".29 \u7684\u4F1A\u8BDD cookie \u53EA\u6709\u540C\u6E90\u9875\u9762\u8BF7\u6C42\u624D\u7A33\u5B9A\u5E26\u4E0A\uFF0C\u9ED8\u8BA4 auto \u5373\u53EF\u3002");
        const resolution = el("input", { type: "number", min: "72", max: "300", step: "10", value: String(settings.resolution || 150) });
        add("PDF \u5206\u8FA8\u7387\uFF08dpi\uFF09", resolution, "\u9875\u9762\u5C3A\u5BF8 = \u50CF\u7D20 \xD7 72 / dpi\uFF1B\u4E0E\u670D\u52A1\u7AEF 150dpi \u5BF9\u9F50\u65F6\u6700\u63A5\u8FD1\u539F\u59CB\u6392\u7248\u3002");
        const concurrency = el("input", { type: "number", min: "1", max: "4", step: "1", value: String(settings.concurrency || 2) });
        add("\u5E76\u53D1\u4E0B\u8F7D\u9875\u6570", concurrency, "1\u20134\uFF1B\u670D\u52A1\u7AEF\u4E0D\u7A33\u65F6\u8C03\u5230 1\u3002");
        const filenameSource = el("select", {}, [
          el("option", { value: "infoname", text: "\u9898\u540D" }),
          el("option", { value: "filename", text: "\u539F\u59CB\u6587\u4EF6\u540D" })
        ]);
        filenameSource.value = settings.filenameSource || "infoname";
        add("PDF \u6587\u4EF6\u540D\u6765\u6E90", filenameSource);
        const saveAs = el("input", { type: "checkbox" });
        saveAs.checked = Boolean(settings.saveAs);
        fields.push(el("label", { class: "check" }, [saveAs, el("span", { text: "\u6BCF\u6B21\u4E0B\u8F7D\u90FD\u5F39\u51FA\u300C\u53E6\u5B58\u4E3A\u300D\u5BF9\u8BDD\u6846" })]));
        const resolveOnSearch = el("input", { type: "checkbox" });
        resolveOnSearch.checked = Boolean(settings.resolveFidOnSearch);
        fields.push(el("label", { class: "check" }, [resolveOnSearch, el("span", { text: "\u68C0\u7D22\u540E\u81EA\u52A8\u5728\u540E\u53F0\u89E3\u6790\u6BCF\u6761\u8BB0\u5F55\u7684 fid" })]));
        const save = el("button", {
          class: "primary",
          text: "\u4FDD\u5B58\u8BBE\u7F6E",
          onClick: async () => {
            try {
              await call("settings:set", {
                patch: {
                  transport: transport.value,
                  resolution: Number(resolution.value) || 150,
                  concurrency: Number(concurrency.value) || 2,
                  filenameSource: filenameSource.value,
                  saveAs: saveAs.checked,
                  resolveFidOnSearch: resolveOnSearch.checked
                }
              });
              showToast("\u5DF2\u4FDD\u5B58");
            } catch (err) {
              showToast(err.message, true);
            }
          }
        });
        for (const field of fields) box.appendChild(field);
        box.appendChild(el("div", { class: "toolbar" }, [save]));
      }).catch((err) => {
        clear(box);
        box.appendChild(el("div", { class: "hint error", text: err.message }));
      });
    }
    function renderLog() {
      const list = el("div", { class: "list" });
      view.appendChild(el("div", { class: "toolbar" }, [
        el("h2", { text: "\u8FD0\u884C\u65E5\u5FD7" }),
        el("span", { class: "spacer" }),
        el("button", {
          class: "danger",
          text: "\u6E05\u7A7A",
          onClick: async () => {
            try {
              await call("log:clear");
              render();
            } catch (err) {
              showToast(err.message, true);
            }
          }
        })
      ]));
      view.appendChild(el("div", { class: "hint", text: "\u672C\u5730\u73AF\u5F62\u65E5\u5FD7\uFF08\u6700\u591A 200 \u6761\uFF09\uFF0C\u4E0D\u542B\u4EFB\u4F55 cookie \u6216\u4EE4\u724C\u5168\u6587\u3002" }));
      view.appendChild(list);
      call("log:get").then((reply) => {
        clear(list);
        const entries = (reply.entries || []).slice().reverse();
        if (!entries.length) {
          list.appendChild(el("div", { class: "empty", text: "\u8FD8\u6CA1\u6709\u65E5\u5FD7\u3002" }));
          return;
        }
        for (const entry of entries) {
          list.appendChild(el("div", { class: "list-item" }, [
            el("span", { class: "t", text: fmtTime(entry.t) }),
            el("span", { class: `lv ${entry.level}`.trim(), text: entry.level }),
            el("span", { class: "m", text: entry.message })
          ]));
        }
      }).catch((err) => {
        clear(list);
        list.appendChild(el("div", { class: "hint error", text: err.message }));
      });
    }
    function renderHelp() {
      view.appendChild(el("h2", { text: "\u4F7F\u7528\u8BF4\u660E" }));
      view.appendChild(el("div", { class: "help card" }, [
        el("ol", {}, [
          el("li", {}, ["\u5728\u6D4F\u89C8\u5668\u91CC\u767B\u5F55 ", el("strong", { text: "\u5170\u5DDE\u5927\u5B66\u56FE\u4E66\u9986\u95E8\u6237" }), "\uFF0C\u5E76\u8FDE\u6821\u5185\u7F51 / VPN\u3002"]),
          el("li", {}, ["\u68C0\u7D22\uFF1A\u8F93\u5165\u4F5C\u8005\u6216\u9898\u540D \u2192 \u56DE\u8F66 \u2192 \u70B9\u67D0\u6761\u8BB0\u5F55\u7684\u300C\u4E0B\u8F7D\u5168\u6587\u300D\uFF1B\u63D2\u4EF6\u4F1A\u81EA\u52A8\u6253\u5F00\u9690\u85CF\u9875\u9762\u8BC6\u522B fid \u5E76\u6293\u53D6\u9875\u9762\u3002"]),
          el("li", {}, ["\u95E8\u6237\u300C\u67E5\u770B\u8BBA\u6587\u4FE1\u606F\u300D\u9875\u3001\u9605\u8BFB\u5668\u9875\u9762\u53F3\u4E0B\u89D2\u4E5F\u4F1A\u51FA\u73B0\u6D6E\u5C42\u6309\u94AE\uFF0C\u53EF\u76F4\u63A5\u4E0B\u8F7D\u3002"]),
          el("li", {}, ["\u4E0B\u8F7D\u7684 PDF \u53EA\u542B\u9605\u8BFB\u5668\u6E32\u67D3\u7684 ", el("strong", { text: "\u56FE\u7247\u9875" }), "\uFF0C\u6CA1\u6709\u6587\u5B57\u5C42\uFF0C\u4E14\u5E26\u95E8\u6237\u6C34\u5370\u3002"]),
          el("li", {}, ["\u4EE4\u724C\u5F88\u77ED\u547D\uFF08\u51E0\u5206\u949F\u5230\u51E0\u5341\u5206\u949F\uFF09\uFF1B\u5931\u6548\u4F1A\u63D0\u793A\u300C\u4EE4\u724C\u5BF9\u5E94\u7684\u6587\u4EF6\u5DF2\u4E0D\u5B58\u5728\u300D\u3002"]),
          el("li", {}, ["\u6293\u53D6\u65F6\u4F1A\u77ED\u6682\u51FA\u73B0\u4E00\u4E2A\u540E\u53F0\u6807\u7B7E\u9875\uFF08", el("code", { text: "tabs.create({active:false})" }), "\uFF09\uFF0C\u53EF\u5FFD\u7565\u3002"])
        ]),
        el("p", { class: "note", text: "\u4EC5\u7528\u4E8E\u4F60\u672C\u6765\u5C31\u6709\u6743\u8BBF\u95EE\u7684\u8BBA\u6587\uFF1B\u8BF7\u9075\u5B88\u5B66\u6821\u4E0E\u6570\u636E\u5E93\u7684\u4F7F\u7528\u6761\u6B3E\uFF0C\u4E0D\u8981\u6279\u91CF\u4E0B\u8F7D\u6216\u4F20\u64AD\u3002" }),
        el("p", { class: "note", text: "\u6280\u672F\u7EC6\u8282\u4E0E\u6545\u969C\u6392\u67E5\u89C1\u63D2\u4EF6\u76EE\u5F55\u4E0B\u7684 README.md\u3002" })
      ]));
    }
    probe(false);
    call("settings:get").then((reply) => {
      state.settings = reply.settings;
      state.lastKeyword = reply.lastKeyword || "";
      if (state.tab === "search" && !state.rows.length) render();
    }).catch(() => {
    });
    call("list-tasks").then((reply) => {
      state.tasks = reply.tasks || [];
      if (state.tab === "tasks") render();
    }).catch(() => {
    });
    api.runtime.onMessage.addListener((message) => {
      if (message && message.type === "task-update" && message.task) mergeTask(message.task);
      return false;
    });
    showTab(state.tab);
    return { showTab, refresh: render };
  }

  // src/ui/popup.js
  mountView(document.getElementById("root"), { compact: true });
})();
