(() => {
  // src/lib/protocol.js
  var READER_ORIGIN = "http://202.201.7.29";
  var PORTAL_ORIGIN = "http://202.201.7.17";
  var REGISTER_PATH = "/personaliiifServlet?path=";
  var INDEX_PATH = "/pdfindex1.jsp?fid=";
  var JUMP_PATH = "/jumpServlet?page=%d&fid=%s";
  var SEARCH_URL = PORTAL_ORIGIN + "/simpsearch.action?ffieldname=xkcode&ffieldkey=07*&dbid=72";
  var SEARCH_POST_PATH = "/zjresult_two.action";
  var RESULT_URLS = ["/zjresult_two.action", "/resultlist.jsp"];
  var DOCINFO_PATH = "/docinfo.action";
  var FID_RE = /\bfid=([0-9a-fA-F]{32})/;
  var GONE_RE = /FileNotFoundException|系统找不到指定的文件|NoSuchFile/i;
  var B64_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  function base64ToBytes(text) {
    const clean = String(text).replace(/[^A-Za-z0-9+/=]/g, "").replace(/=+$/, "");
    if (!clean) return new Uint8Array(0);
    const padded = clean + "=".repeat((4 - clean.length % 4) % 4);
    const bin = atob(padded);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function bytesToBase64(bytes) {
    const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const parts = [];
    let chunk = "";
    for (let i = 0; i < arr.length; i += 3) {
      const b0 = arr[i];
      const b1 = i + 1 < arr.length ? arr[i + 1] : 0;
      const b2 = i + 2 < arr.length ? arr[i + 2] : 0;
      chunk += B64_ALPHABET[b0 >> 2] + B64_ALPHABET[(b0 & 3) << 4 | b1 >> 4] + (i + 1 < arr.length ? B64_ALPHABET[(b1 & 15) << 2 | b2 >> 6] : "=") + (i + 2 < arr.length ? B64_ALPHABET[b2 & 63] : "=");
      if (chunk.length >= 32768) {
        parts.push(chunk);
        chunk = "";
      }
    }
    if (chunk) parts.push(chunk);
    return parts.join("");
  }
  function unquote(text) {
    const src = String(text);
    const bytes = [];
    for (let i = 0; i < src.length; i++) {
      const ch = src[i];
      if (ch === "%" && /^[0-9a-fA-F]{2}$/.test(src.slice(i + 1, i + 3))) {
        bytes.push(parseInt(src.slice(i + 1, i + 3), 16));
        i += 2;
      } else {
        const code = src.charCodeAt(i);
        if (code < 128) {
          bytes.push(code);
        } else {
          for (const b of new TextEncoder().encode(src[i])) bytes.push(b);
        }
      }
    }
    return new TextDecoder("utf-8", { fatal: false }).decode(new Uint8Array(bytes));
  }
  function quote(text, safe = "") {
    let out = encodeURIComponent(String(text)).replace(
      /[!'()*]/g,
      (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase()
    );
    for (const ch of String(safe)) {
      if (ch.charCodeAt(0) > 127) continue;
      const enc = "%" + ch.charCodeAt(0).toString(16).toUpperCase();
      out = out.split(enc).join(ch);
    }
    return out;
  }
  function extractToken(input) {
    const text = String(input || "").trim();
    if (!text) return "";
    const m = /personaliiifServlet\?path=([A-Za-z0-9+/=%]+)/.exec(text);
    if (m) return m[1];
    if (/^[A-Za-z0-9+/=%]{20,}$/.test(text)) return text;
    return "";
  }
  function decodeToken(token) {
    const raw = String(token || "").trim();
    if (raw.length < 6) throw new Error("\u4EE4\u724C\u592A\u77ED\uFF0C\u65E0\u6CD5\u89E3\u6790");
    const prefix = raw.slice(0, 5);
    const body = raw.slice(5).replace(/%3[dD]/g, "=");
    let payload;
    try {
      payload = new TextDecoder("utf-8", { fatal: false }).decode(base64ToBytes(body));
    } catch (err) {
      throw new Error(`\u4EE4\u724C base64 \u89E3\u7801\u5931\u8D25\uFF1A${err.message}`);
    }
    const parts = payload.split("&");
    const path = unquote(parts.shift() || "");
    const fields = /* @__PURE__ */ Object.create(null);
    for (const kv of parts) {
      const idx = kv.indexOf("=");
      if (idx > 0) fields[kv.slice(0, idx)] = unquote(kv.slice(idx + 1));
    }
    const num2 = (v) => {
      const n = Number.parseInt(v, 10);
      return Number.isFinite(n) ? n : null;
    };
    const storeName = path.split(/[\\/]/).pop() || path;
    return {
      prefix,
      path,
      storeName,
      startpage: num2(fields.startpage),
      endpage: num2(fields.endpage),
      down: num2(fields.down),
      watermark: fields.watermark || "",
      filename: fields.filename || "",
      infoname: fields.infoname || "",
      fields: Object.freeze({ ...fields })
    };
  }
  function quoteToken(token) {
    return quote(token, "");
  }
  function originOf(input) {
    try {
      return new URL(input).origin;
    } catch {
      const s = String(input).replace(/\/+$/, "");
      if (/^\d+\.\d+\.\d+\.\d+$/.test(s)) return `http://${s}`;
      return s;
    }
  }

  // src/lib/ext.js
  var api = globalThis.browser ?? globalThis.chrome;
  var navUserAgent = (() => {
    try {
      return String(typeof navigator !== "undefined" && navigator.userAgent || "");
    } catch {
      return "";
    }
  })();
  var isFirefox = typeof (api && api.runtime && api.runtime.getBrowserInfo) === "function" || navUserAgent.includes("Firefox/");
  var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function runtimeURL(path) {
    return api.runtime.getURL(path);
  }
  async function broadcast(message) {
    try {
      await api.runtime.sendMessage(message);
    } catch {
    }
  }
  async function getTab(tabId) {
    try {
      return await api.tabs.get(tabId);
    } catch {
      return null;
    }
  }
  var LOG_KEY = "log";
  var LOG_LIMIT = 200;
  async function logEvent(level, message, extra) {
    try {
      const got = await api.storage.local.get(LOG_KEY);
      const list = Array.isArray(got[LOG_KEY]) ? got[LOG_KEY] : [];
      list.push({
        t: Date.now(),
        level: String(level || "info"),
        message: String(message || ""),
        extra: extra ? JSON.parse(JSON.stringify(extra)) : void 0
      });
      await api.storage.local.set({ [LOG_KEY]: list.slice(-LOG_LIMIT) });
    } catch {
    }
    if (level === "error") console.warn("[LZU]", message, extra || "");
  }
  async function readLog() {
    const got = await api.storage.local.get(LOG_KEY);
    return Array.isArray(got[LOG_KEY]) ? got[LOG_KEY] : [];
  }
  async function clearLog() {
    await api.storage.local.set({ [LOG_KEY]: [] });
  }
  async function openAppPage(hash = "") {
    const url = runtimeURL("app.html") + (hash ? `#${hash}` : "");
    try {
      const existing = await api.tabs.query({ url: runtimeURL("app.html") + "*" });
      if (existing && existing.length) {
        await api.tabs.update(existing[0].id, { active: true, url });
        return existing[0].id;
      }
    } catch {
    }
    const tab = await api.tabs.create({ url });
    return tab.id;
  }

  // src/lib/http.js
  var HttpError = class extends Error {
    constructor(message, { status = null, url = "", body = "", cause = null } = {}) {
      super(message);
      this.name = "HttpError";
      this.status = status;
      this.url = url;
      this.body = body;
      this.cause = cause;
    }
  };
  var GoneError = class extends HttpError {
    constructor(message, opts = {}) {
      super(message, opts);
      this.name = "GoneError";
    }
  };
  var AppError = class extends Error {
    constructor(message, code = "APP_ERROR") {
      super(message);
      this.name = "AppError";
      this.code = code;
    }
  };
  var CHARSET_RE = /charset\s*=\s*["']?([\w-]+)/i;
  var META_CHARSET_RE = /<meta[^>]+charset\s*=\s*["']?([\w-]+)/i;
  function decodeText(bytes, contentType = "") {
    const buf = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
    let charset = "";
    const m = CHARSET_RE.exec(contentType || "");
    if (m) charset = m[1].toLowerCase();
    if (!charset) {
      const head = new TextDecoder("latin1").decode(buf.subarray(0, 4096));
      const mm = META_CHARSET_RE.exec(head);
      if (mm) charset = mm[1].toLowerCase();
    }
    if (charset === "gb2312" || charset === "gbk" || charset === "gb18030") {
      try {
        return new TextDecoder("gb18030", { fatal: false }).decode(buf);
      } catch {
      }
    }
    return new TextDecoder("utf-8", { fatal: false }).decode(buf);
  }
  var sleep2 = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function createHttp(request, { retries = 3, timeoutMs = 45e3, delay = 1.5 } = {}) {
    const headersOf = (res) => {
      const out = {};
      for (const [k, v] of Object.entries(res.headers || {})) out[k.toLowerCase()] = v;
      return out;
    };
    async function raw(url, opts = {}) {
      const tries = Math.max(1, opts.retries ?? retries);
      const baseDelay = opts.delay ?? delay;
      let last = null;
      for (let attempt = 0; attempt < tries; attempt++) {
        try {
          const res = await request({
            url,
            method: opts.method || "GET",
            headers: opts.headers || {},
            body: opts.body ?? null,
            timeoutMs: opts.timeoutMs ?? timeoutMs
          });
          return {
            status: res.status,
            url: res.url || url,
            headers: headersOf(res),
            body: res.body || new Uint8Array(0)
          };
        } catch (err) {
          last = err;
          const isAbort = err && (err.name === "AbortError" || err.name === "TimeoutError");
          if (isAbort) throw err;
          if (attempt + 1 < tries) await sleep2(baseDelay * 1e3 * (attempt + 1));
        }
      }
      throw new HttpError(`\u7F51\u7EDC\u8BF7\u6C42\u5931\u8D25\uFF1A${last && last.message}`, { url, cause: last });
    }
    function check(res, { asText = true } = {}) {
      if (res.status >= 200 && res.status < 400) return res;
      const text2 = asText ? decodeText(res.body, res.headers["content-type"]) : "";
      const snippet = text2.slice(0, 400);
      if (res.status >= 500 && GONE_RE.test(text2)) {
        throw new GoneError(
          `\u670D\u52A1\u7AEF\u627E\u4E0D\u5230\u8BE5\u6587\u4EF6\uFF08HTTP ${res.status}\uFF09\u3002\u4EE4\u724C\u53EF\u80FD\u5DF2\u8FC7\u671F\uFF0C\u6216\u6587\u4EF6\u5DF2\u4E0D\u5728\u670D\u52A1\u5668\u4E0A\u3002`,
          { status: res.status, url: res.url, body: snippet }
        );
      }
      throw new HttpError(
        `HTTP ${res.status}\uFF1A${snippet.slice(0, 160) || res.url}`,
        { status: res.status, url: res.url, body: snippet }
      );
    }
    async function withStatus(url, opts = {}) {
      const res = await raw(url, opts);
      return check(res, { asText: opts.asText !== false });
    }
    async function text(url, opts = {}) {
      const res = await withStatus(url, { ...opts, asText: true });
      return decodeText(res.body, res.headers["content-type"]);
    }
    async function bytes(url, opts = {}) {
      const res = await withStatus(url, { ...opts, asText: false });
      return res.body;
    }
    async function json(url, opts = {}) {
      const rawText = await text(url, opts);
      try {
        return JSON.parse(rawText);
      } catch (err) {
        throw new AppError(`\u8FD4\u56DE\u7684\u4E0D\u662F JSON\uFF1A${rawText.slice(0, 120)}`, "BAD_JSON");
      }
    }
    async function postForm(url, fields, opts = {}) {
      const body = new URLSearchParams(fields).toString();
      return text(url, {
        ...opts,
        method: "POST",
        body,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          ...opts.headers || {}
        }
      });
    }
    return { raw, text, bytes, json, postForm, request, check };
  }

  // src/lib/reader.js
  var META_FIELDS = [
    "fid",
    "sum",
    "pageCount",
    "startpage",
    "endpage",
    "filename",
    "infoname",
    "watermark",
    "pdfchange",
    "pagewidth",
    "pageheight"
  ];
  var NULLISH = /* @__PURE__ */ new Set(["", "null", "NULL", "Null", "undefined"]);
  var escapeRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  function hiddenValue(html, name) {
    const n = escapeRe(name);
    const patterns = [
      new RegExp(`id="${n}"[^>]*?value="([^"]*)"`),
      new RegExp(`value="([^"]*)"[^>]*?id="${n}"`),
      new RegExp(`name="${n}"[^>]*?value="([^"]*)"`),
      new RegExp(`value="([^"]*)"[^>]*?name="${n}"`)
    ];
    const src = String(html || "");
    for (const re of patterns) {
      const m = re.exec(src);
      if (m && !NULLISH.has(m[1])) return m[1];
    }
    return null;
  }
  function parseMeta(html) {
    const meta = {};
    for (const key of META_FIELDS) meta[key] = hiddenValue(html, key);
    return meta;
  }
  function pageCount(meta) {
    for (const key of ["pageCount", "sum", "endpage"]) {
      const v = meta && meta[key];
      if (v !== null && v !== void 0 && /^\d+$/.test(String(v))) {
        const n = Number.parseInt(v, 10);
        if (n > 0) return n;
      }
    }
    throw new AppError(
      "\u8BFB\u4E0D\u5230\u9875\u6570\uFF1A\u8FD9\u4E2A\u4F1A\u8BDD\u91CC\u53EF\u80FD\u6CA1\u6709\u8BE5\u6587\u6863\uFF08pdfindex1.jsp \u5B57\u6BB5\u5168\u662F null\uFF09\u3002 fid \u5FC5\u987B\u5148\u5728\u5F53\u524D\u6D4F\u89C8\u5668\u4F1A\u8BDD\u91CC\u6CE8\u518C\u8FC7\u3002",
      "NO_META"
    );
  }
  function titleOf(meta, fid = "") {
    return meta && (meta.infoname || meta.filename) || fid;
  }
  function parseJumpPayload(text) {
    let data;
    try {
      data = JSON.parse(String(text || "").trim());
    } catch {
      return [];
    }
    const list = data && data.list || [];
    if (!Array.isArray(list)) return [];
    const out = [];
    for (const it of list) {
      if (!it || it.src === void 0 || it.id === void 0) continue;
      out.push({ id: it.id, src: String(it.src) });
    }
    return out;
  }
  function absolutePageUrl(src) {
    const s = String(src || "").trim();
    if (!s) return "";
    if (/^https?:\/\//i.test(s)) return s;
    if (s.startsWith("//")) return `http:${s}`;
    return `${READER_ORIGIN}/${s.replace(/^\/+/, "")}`;
  }
  async function collectPageUrls(http, fid, n, opts = {}) {
    const onProgress = opts.onProgress || (() => {
    });
    const pages = /* @__PURE__ */ new Map();
    let attempts = 0;
    const fetchOne = async (p) => {
      attempts++;
      let text;
      try {
        text = await http.text(`${READER_ORIGIN}${JUMP_PATH.replace("%d", p).replace("%s", fid)}`, {
          signal: opts.signal
        });
      } catch (err) {
        if (err instanceof AppError) throw err;
        return;
      }
      for (const it of parseJumpPayload(text)) {
        const id = Number.parseInt(it.id, 10);
        if (!Number.isFinite(id)) continue;
        pages.set(id, absolutePageUrl(it.src));
      }
    };
    for (let p = 0; p < n + 2; p++) {
      await fetchOne(p);
      if (pages.size >= n) break;
    }
    const rounds = Math.max(0, opts.extraRounds ?? 2);
    for (let round = 0; round < rounds; round++) {
      const missing2 = [];
      for (let i = 0; i < n; i++) if (!pages.has(i)) missing2.push(i);
      if (!missing2.length) break;
      onProgress({ done: pages.size, total: n, msg: `\u8865\u6293 ${missing2.length} \u4E2A\u7F3A\u5931\u9875\uFF08\u7B2C ${round + 1} \u8F6E\uFF09` });
      for (const p of missing2) await fetchOne(p);
    }
    const missing = [];
    for (let i = 0; i < n; i++) if (!pages.has(i)) missing.push(i);
    return { pages, missing, attempts };
  }
  async function fetchPageBytes(http, url, opts = {}) {
    const bytes = await http.bytes(url, { signal: opts.signal });
    return validateJpeg(bytes, url);
  }
  function validateJpeg(bytes, url = "") {
    if (!bytes || bytes.length < 1024) {
      throw new AppError(`\u7B2C ${url} \u9875\u8FD4\u56DE\u7684\u6570\u636E\u592A\u5C0F\uFF08${bytes ? bytes.length : 0} B\uFF09`, "BAD_PAGE");
    }
    if (bytes[0] !== 255 || bytes[1] !== 216) {
      const head = new TextDecoder("utf-8", { fatal: false }).decode(bytes.subarray(0, 300));
      if (GONE_RE.test(head)) {
        throw new AppError("\u670D\u52A1\u7AEF\u8FD4\u56DE\u201C\u6587\u4EF6\u4E0D\u5B58\u5728\u201D\uFF0C\u4EE4\u724C\u6216\u4F1A\u8BDD\u53EF\u80FD\u5DF2\u5931\u6548\u3002", "GONE");
      }
      throw new AppError(`\u8FD4\u56DE\u7684\u4E0D\u662F JPEG\uFF08\u5F00\u5934 ${Array.from(bytes.subarray(0, 4), (b) => b.toString(16).padStart(2, "0")).join(" ")}\uFF09`, "NOT_JPEG");
    }
    return bytes;
  }

  // src/lib/portal.js
  var ROW_RE = /docinfo\('([0-9a-fA-F]+)','([^']+)'\)">([\s\S]*?)<\/a>/g;
  var ONLINE_RE = /href="(onlinePDF[^"]+)"/g;
  var TOTAL_RE = /共\s*(?:<[^>]*>\s*)*([0-9]+)/;
  var NAMED_ENTITIES = {
    amp: "&",
    lt: "<",
    gt: ">",
    quot: '"',
    apos: "'",
    nbsp: " ",
    middot: "\xB7",
    ldquo: "\u201C",
    rdquo: "\u201D",
    lsquo: "\u2018",
    rsquo: "\u2019",
    mdash: "\u2014",
    ndash: "\u2013",
    hellip: "\u2026",
    times: "\xD7",
    bull: "\u2022"
  };
  function decodeEntities(text) {
    return String(text || "").replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (all, body) => {
      if (body[0] === "#") {
        const hex = body[1] === "x" || body[1] === "X";
        const code = Number.parseInt(hex ? body.slice(2) : body.slice(1), hex ? 16 : 10);
        if (!Number.isFinite(code) || code <= 0 || code > 1114111) return all;
        try {
          return String.fromCodePoint(code);
        } catch {
          return all;
        }
      }
      const named = NAMED_ENTITIES[body.toLowerCase()];
      return named === void 0 ? all : named;
    });
  }
  function stripTags(html) {
    return decodeEntities(String(html || "").replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim();
  }
  function parseRows(html) {
    const src = String(html || "");
    const rows = [];
    const seen = /* @__PURE__ */ new Set();
    for (const m of src.matchAll(ROW_RE)) {
      const id1 = m[1].toLowerCase();
      const id2 = m[2];
      const key = `${id1}|${id2}`;
      if (seen.has(key)) continue;
      seen.add(key);
      rows.push({ id1, id2, title: stripTags(m[3]) });
    }
    return rows;
  }
  function parseTotal(html) {
    const m = TOTAL_RE.exec(String(html || ""));
    return m ? Number.parseInt(m[1], 10) : null;
  }
  function onlineLinks(html) {
    const src = decodeEntities(String(html || ""));
    const links = /* @__PURE__ */ new Set();
    for (const m of src.matchAll(ONLINE_RE)) links.add(m[1]);
    return Array.from(links).sort();
  }
  function absoluteUrl(link, base = PORTAL_ORIGIN) {
    const s = String(link || "").trim();
    if (!s) return "";
    if (/^https?:\/\//i.test(s)) return s;
    if (s.startsWith("//")) return `http:${s}`;
    return `${base}/${s.replace(/^\/+/, "")}`;
  }
  async function search(http, keyword, opts = {}) {
    const kw = String(keyword || "").trim();
    if (!kw) throw new Error("\u8BF7\u8F93\u5165\u68C0\u7D22\u5173\u952E\u8BCD");
    const onStep = opts.onStep || (() => {
    });
    onStep("\u6253\u5F00\u68C0\u7D22\u9875\u2026");
    await http.text(SEARCH_URL, { signal: opts.signal });
    onStep("\u63D0\u4EA4\u68C0\u7D22\u2026");
    await http.postForm(PORTAL_ORIGIN + SEARCH_POST_PATH, {
      searchkeyword: kw,
      searchstrs: `all:${kw}:and`,
      ffields: "",
      ffieldstr: ""
    }, { signal: opts.signal });
    let total = null;
    for (const path of RESULT_URLS) {
      let html;
      try {
        html = await http.text(PORTAL_ORIGIN + path, { signal: opts.signal });
      } catch (err) {
        if (opts.onStep) opts.onStep(`\u7ED3\u679C\u9875 ${path} \u4E0D\u53EF\u7528\uFF08${err.message}\uFF09`);
        continue;
      }
      const rows = parseRows(html);
      const t = parseTotal(html);
      if (t !== null && total === null) total = t;
      if (rows.length) {
        return { rows, total: total ?? rows.length, source: path };
      }
    }
    return { rows: [], total: total ?? 0, source: "" };
  }
  async function docinfoHtml(http, id1, id2, opts = {}) {
    return http.postForm(PORTAL_ORIGIN + DOCINFO_PATH, { id1, id2 }, { signal: opts.signal });
  }
  async function recordLinks(http, record, opts = {}) {
    const html = await docinfoHtml(http, record.id1, record.id2, opts);
    const links = onlineLinks(html);
    return { links, absLinks: links.map((l) => absoluteUrl(l)), html };
  }

  // src/lib/pdf.js
  var encoder = new TextEncoder();
  var ascii = (s) => encoder.encode(s);
  var ByteSink = class {
    constructor() {
      this.chunks = [];
      this.length = 0;
    }
    push(bytes) {
      this.chunks.push(bytes);
      this.length += bytes.length;
    }
    pushText(s) {
      this.push(ascii(s));
    }
    toUint8Array() {
      const out = new Uint8Array(this.length);
      let off = 0;
      for (const c of this.chunks) {
        out.set(c, off);
        off += c.length;
      }
      return out;
    }
  };
  function num(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return "0";
    const rounded = Math.round(n * 100) / 100;
    return Number.isInteger(rounded) ? String(rounded) : String(rounded);
  }
  function pdfString(text) {
    const s = String(text ?? "");
    if (/^[\x20-\x7e]*$/.test(s)) {
      return "(" + s.replace(/[\\()]/g, (c) => "\\" + c) + ")";
    }
    let hex = "FEFF";
    const bytes = new Uint8Array(s.length * 2);
    for (let i = 0; i < s.length; i++) {
      const code = s.charCodeAt(i);
      bytes[i * 2] = code >> 8;
      bytes[i * 2 + 1] = code & 255;
      hex += (code >> 8).toString(16).padStart(2, "0") + (code & 255).toString(16).padStart(2, "0");
    }
    return "<" + hex.toUpperCase() + ">";
  }
  function jpegInfo(bytes) {
    if (!bytes || bytes.length < 4 || bytes[0] !== 255 || bytes[1] !== 216) {
      throw new Error("\u4E0D\u662F JPEG \u6570\u636E\uFF08\u7F3A\u5C11 FFD8 \u5934\uFF09");
    }
    let pos = 2;
    let adobeTransform = null;
    while (pos + 3 < bytes.length) {
      if (bytes[pos] !== 255) {
        pos++;
        continue;
      }
      const marker = bytes[pos + 1];
      if (marker === 216 || marker === 1 || marker >= 208 && marker <= 215) {
        pos += 2;
        continue;
      }
      if (marker === 218 || marker === 217) break;
      const len = bytes[pos + 2] << 8 | bytes[pos + 3];
      if (len < 2 || pos + 2 + len > bytes.length) break;
      const isSOF = marker >= 192 && marker <= 207 && marker !== 196 && marker !== 200 && marker !== 204;
      if (isSOF) {
        const height = bytes[pos + 5] << 8 | bytes[pos + 6];
        const width = bytes[pos + 7] << 8 | bytes[pos + 8];
        const components = bytes[pos + 9];
        return { width, height, components, adobeTransform };
      }
      if (marker === 238) {
        const data = bytes.subarray(pos + 4, pos + 2 + len);
        if (data.length >= 12 && data[0] === 65 && data[1] === 100 && data[2] === 111 && data[3] === 98 && data[4] === 101) {
          adobeTransform = data[11];
        }
      }
      pos += 2 + len;
    }
    throw new Error("JPEG \u91CC\u627E\u4E0D\u5230 SOF \u6BB5\uFF0C\u8BFB\u4E0D\u51FA\u5C3A\u5BF8");
  }
  function buildPdf(pages, opts = {}) {
    if (!Array.isArray(pages) || pages.length === 0) {
      throw new Error("\u6CA1\u6709\u4EFB\u4F55\u9875\u9762\uFF0C\u65E0\u6CD5\u5408\u6210 PDF");
    }
    const resolution = Number(opts.resolution) > 0 ? Number(opts.resolution) : 150;
    const n = pages.length;
    const sink = new ByteSink();
    const offsets = [];
    sink.pushText("%PDF-1.4\n");
    sink.push(new Uint8Array([37, 226, 227, 207, 211, 10]));
    const beginObj = (id) => {
      offsets[id] = sink.length;
      sink.pushText(`${id} 0 obj
`);
    };
    const endObj = () => sink.pushText("endobj\n");
    beginObj(1);
    sink.pushText("<< /Type /Catalog /Pages 2 0 R >>\n");
    endObj();
    const kids = pages.map((_, i) => `${4 + 3 * i} 0 R`).join(" ");
    beginObj(2);
    sink.pushText(`<< /Type /Pages /Kids [ ${kids} ] /Count ${n} >>
`);
    endObj();
    beginObj(3);
    const infoParts = ["/Producer " + pdfString(opts.producer || "LZU Fulltext extension")];
    if (opts.title) infoParts.push("/Title " + pdfString(opts.title));
    infoParts.push("/Creator " + pdfString(opts.creator || "LZU Fulltext extension"));
    sink.pushText(`<< ${infoParts.join(" ")} >>
`);
    endObj();
    for (let i = 0; i < n; i++) {
      const page = pages[i];
      const { width, height, components } = page.info;
      const pageW = width * 72 / resolution;
      const pageH = height * 72 / resolution;
      const pageId = 4 + 3 * i;
      const contentId = pageId + 1;
      const imageId = pageId + 2;
      beginObj(pageId);
      sink.pushText(
        `<< /Type /Page /Parent 2 0 R /MediaBox [ 0 0 ${num(pageW)} ${num(pageH)} ] /Resources << /XObject << /Im0 ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>
`
      );
      endObj();
      const content = `q
${num(pageW)} 0 0 ${num(pageH)} 0 0 cm
/Im0 Do
Q
`;
      const contentBytes = ascii(content);
      beginObj(contentId);
      sink.pushText(`<< /Length ${contentBytes.length} >>
stream
`);
      sink.push(contentBytes);
      sink.pushText("endstream\n");
      endObj();
      let colorSpace = "/DeviceRGB";
      let decode = "";
      if (components === 1) colorSpace = "/DeviceGray";
      else if (components === 4) {
        colorSpace = "/DeviceCMYK";
        if (page.info.adobeTransform !== null) decode = " /Decode [1 0 1 0 1 0]";
      }
      const jpeg = page.jpeg;
      beginObj(imageId);
      sink.pushText(
        `<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace ${colorSpace} /BitsPerComponent 8 /Filter /DCTDecode${decode} /Length ${jpeg.length} >>
stream
`
      );
      sink.push(jpeg);
      sink.pushText("\nendstream\n");
      endObj();
    }
    const xrefStart = sink.length;
    const total = 3 + 3 * n + 1;
    sink.pushText(`xref
0 ${total}
`);
    sink.pushText("0000000000 65535 f \n");
    for (let id = 1; id < total; id++) {
      sink.pushText(`${String(offsets[id] || 0).padStart(10, "0")} 00000 n 
`);
    }
    sink.pushText(`trailer
<< /Size ${total} /Root 1 0 R /Info 3 0 R >>
startxref
${xrefStart}
%%EOF
`);
    return sink.toUint8Array();
  }
  function safeName(name, { fallback = "document", limit = 80 } = {}) {
    const bad = '\\/:*?"<>|\r\n	';
    let out = "";
    for (const ch of String(name || "")) out += bad.includes(ch) ? "_" : ch;
    out = out.replace(/^[ .]+/, "").replace(/[ .]+$/, "");
    return (out || fallback).slice(0, limit);
  }

  // src/lib/pipeline.js
  async function mapPool(items, limit, worker, opts = {}) {
    const results = new Array(items.length);
    let cursor = 0;
    const lanes = Math.max(1, Math.min(limit, items.length));
    const checkAbort = () => {
      if (opts.signal && opts.signal.aborted) {
        throw new AppError("\u5DF2\u53D6\u6D88", "CANCELLED");
      }
    };
    const run = async () => {
      for (; ; ) {
        const i = cursor++;
        if (i >= items.length) return;
        checkAbort();
        results[i] = await worker(items[i], i);
      }
    };
    await Promise.all(Array.from({ length: lanes }, run));
    return results;
  }
  async function downloadDocument(spec) {
    const {
      http,
      fid,
      meta,
      resolution = 150,
      concurrency = 2,
      pageRetries = 2
    } = spec;
    const signal = spec.signal;
    const emit = spec.onProgress || (() => {
    });
    if (!fid) throw new AppError("\u7F3A\u5C11 fid", "NO_FID");
    const n = pageCount(meta);
    const title = titleOf(meta, fid);
    emit({ phase: "meta", done: 0, total: n, title });
    emit({ phase: "urls", done: 0, total: n, msg: `\u5171 ${n} \u9875\uFF0C\u83B7\u53D6\u9875\u9762\u5730\u5740\u2026`, title });
    const { pages: urlMap, missing } = await collectPageUrls(http, fid, n, {
      signal,
      onProgress: (p) => emit({ phase: "urls", done: p.done, total: p.total, msg: p.msg, title })
    });
    if (missing.length) {
      throw new AppError(
        `\u6709 ${missing.length} \u9875\u62FF\u4E0D\u5230\u56FE\u7247\u5730\u5740\uFF08\u7B2C ${missing.slice(0, 10).map((i) => i + 1).join("\u3001")}${missing.length > 10 ? "\u2026" : ""} \u9875\uFF09\u3002 \u9605\u8BFB\u5668\u670D\u52A1\u53EF\u80FD\u4E0D\u7A33\u5B9A\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002`,
        "MISSING_PAGES"
      );
    }
    const indices = Array.from({ length: n }, (_, i) => i);
    let done = 0;
    const pages = await mapPool(indices, concurrency, async (i) => {
      const url = urlMap.get(i);
      let lastErr = null;
      for (let attempt = 0; attempt <= pageRetries; attempt++) {
        if (signal && signal.aborted) throw new AppError("\u5DF2\u53D6\u6D88", "CANCELLED");
        try {
          const bytes = await fetchPageBytes(http, url, { signal });
          const info = jpegInfo(bytes);
          done++;
          emit({ phase: "pages", done, total: n, msg: `\u7B2C ${i + 1}/${n} \u9875`, title });
          return { jpeg: bytes, info };
        } catch (err) {
          lastErr = err;
          if (err && (err.code === "GONE" || err instanceof GoneError)) break;
          if (attempt < pageRetries) {
            await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
          }
        }
      }
      throw new AppError(`\u7B2C ${i + 1} \u9875\u4E0B\u8F7D\u5931\u8D25\uFF1A${lastErr && lastErr.message}`, "PAGE_FAILED");
    }, { signal });
    emit({ phase: "build", done: n, total: n, msg: "\u5408\u6210 PDF\u2026", title });
    const pdf = buildPdf(pages, { title, resolution });
    const filename = `${safeName(title, { fallback: fid.slice(0, 8) })}.pdf`;
    return {
      pdf,
      filename,
      title,
      pageCount: n,
      meta,
      pageSizes: pages.map((p) => [p.info.width, p.info.height])
    };
  }

  // src/lib/settings.js
  var DEFAULT_SETTINGS = {
    /** PDF 里标注的物理尺寸用：像素 × 72 / resolution（与 CLI 的 Pillow resolution=150 对齐）。 */
    resolution: 150,
    /** 每页图片并发数（对 .29 太猛会触发限流）。 */
    concurrency: 2,
    /** 传输方式：auto = 同源桥接优先，失败退回后台 fetch。 */
    transport: "auto",
    /** 文件名取哪个字段。 */
    filenameSource: "infoname",
    /** 下载时是否弹“另存为”。 */
    saveAs: false,
    /** 检索时是否顺便识别 fid（会为每条记录短暂开标签页，慢）。 */
    resolveFidOnSearch: false
  };
  var KEY = "settings";
  async function getSettings() {
    try {
      const got = await api.storage.local.get(KEY);
      return { ...DEFAULT_SETTINGS, ...got[KEY] || {} };
    } catch {
      return { ...DEFAULT_SETTINGS };
    }
  }
  async function setSettings(patch) {
    const current = await getSettings();
    const next = { ...current, ...patch };
    await api.storage.local.set({ [KEY]: next });
    return next;
  }
  var LAST_KEYWORD = "lastKeyword";
  async function getLastKeyword() {
    try {
      const got = await api.storage.local.get(LAST_KEYWORD);
      return typeof got[LAST_KEYWORD] === "string" ? got[LAST_KEYWORD] : "";
    } catch {
      return "";
    }
  }
  async function setLastKeyword(keyword) {
    try {
      await api.storage.local.set({ [LAST_KEYWORD]: String(keyword || "") });
    } catch {
    }
  }

  // src/background/tabs.js
  var TAB_CLOSED = new AppError("\u6807\u7B7E\u9875\u5DF2\u88AB\u5173\u95ED", "TAB_CLOSED");
  var NAV_ERROR = new AppError("\u9875\u9762\u6253\u4E0D\u5F00\uFF08\u8FDE\u63A5\u5931\u8D25\uFF09", "NAV_ERROR");
  var ERROR_URL_PREFIXES = ["chrome-error://", "about:neterror", "about:blocked", "edge-error://"];
  function isErrorPageUrl(url) {
    const s = String(url || "");
    return ERROR_URL_PREFIXES.some((p) => s.startsWith(p));
  }
  async function waitForTab(tabId, check, {
    timeoutMs = 3e4,
    pollMs = 350,
    signal = null,
    what = "\u9875\u9762"
  } = {}) {
    const start = Date.now();
    for (; ; ) {
      if (signal && signal.aborted) throw new AppError("\u5DF2\u53D6\u6D88", "CANCELLED");
      const tab = await getTab(tabId);
      if (!tab) throw TAB_CLOSED;
      const url = tab.url || tab.pendingUrl || "";
      if (isErrorPageUrl(url)) {
        throw new AppError(`\u6253\u4E0D\u5F00${what}\uFF1A\u8FDE\u63A5\u5931\u8D25\uFF08\u9605\u8BFB\u5668 202.201.7.29 \u53EF\u80FD\u53EA\u5728\u6821\u5185\u7F51\u53EF\u8FBE\uFF09`, "NAV_ERROR");
      }
      const value = await check(tab);
      if (value) return value;
      if (Date.now() - start > timeoutMs) {
        throw new AppError(`\u7B49\u5F85${what}\u8D85\u65F6\uFF08${Math.round(timeoutMs / 1e3)} \u79D2\uFF09`, "TIMEOUT");
      }
      await sleep(pollMs);
    }
  }
  async function waitComplete(tabId, opts = {}) {
    return waitForTab(tabId, (tab) => tab.status === "complete" ? tab : null, { what: "\u9875\u9762\u52A0\u8F7D", ...opts });
  }
  async function waitForFid(tabId, opts = {}) {
    return waitForTab(tabId, (tab) => {
      const url = tab.url || "";
      const m = FID_RE.exec(url);
      return m ? { fid: m[1].toLowerCase(), url } : null;
    }, { what: "\u9605\u8BFB\u5668\u521D\u59CB\u5316\uFF08fid\uFF09", ...opts });
  }
  async function createHiddenTab(url) {
    const tab = await api.tabs.create({ url, active: false });
    return tab.id;
  }
  async function closeTab(tabId) {
    try {
      await api.tabs.remove(tabId);
    } catch {
    }
  }
  async function findTabsByOrigin(origin) {
    try {
      const tabs = await api.tabs.query({});
      return (tabs || []).filter((t) => (t.url || "").startsWith(origin));
    } catch {
      return [];
    }
  }
  async function sendToTab(tabId, message, { tries = 14, interval = 250, timeoutMs = 2e4 } = {}) {
    const start = Date.now();
    let lastErr = null;
    for (let i = 0; i < tries; i++) {
      if (Date.now() - start > timeoutMs) break;
      try {
        const reply = await api.tabs.sendMessage(tabId, message);
        if (reply !== void 0) return reply;
      } catch (err) {
        lastErr = err;
      }
      if (!await getTab(tabId)) throw TAB_CLOSED;
      await sleep(interval);
    }
    throw new AppError(`\u9875\u9762\u811A\u672C\u65E0\u54CD\u5E94\uFF1A${lastErr ? lastErr.message : "\u8D85\u65F6"}`, "NO_CONTENT_SCRIPT");
  }
  async function waitForBridge(tabId, { timeoutMs = 8e3 } = {}) {
    return sendToTab(tabId, { type: "ping" }, { tries: Math.ceil(timeoutMs / 250), timeoutMs });
  }
  async function ensureWorker(origin, {
    url = "",
    timeoutMs = 3e4,
    signal = null
  } = {}) {
    for (const tab of await findTabsByOrigin(origin)) {
      try {
        const pong = await waitForBridge(tab.id, { timeoutMs: 2500 });
        if (pong && pong.ok) return { tabId: tab.id, created: false, url: tab.url || "" };
      } catch {
      }
    }
    const tabId = await createHiddenTab(url || `${origin}/`);
    await waitComplete(tabId, { timeoutMs, signal });
    await waitForBridge(tabId, { timeoutMs: 12e3 });
    return { tabId, created: true, url: url || `${origin}/` };
  }

  // src/background/transport.js
  var WORKER_URLS = {
    [PORTAL_ORIGIN]: PORTAL_ORIGIN + "/simpsearch.action?ffieldname=xkcode&ffieldkey=07*&dbid=72",
    [READER_ORIGIN]: READER_ORIGIN + "/"
  };
  var workers = /* @__PURE__ */ new Map();
  function setWorker(origin, tabId) {
    if (tabId) workers.set(origin, tabId);
    else workers.delete(origin);
  }
  async function bridgeRequest(spec) {
    const origin = originOf(spec.url) || "";
    let tabId = workers.get(origin);
    if (!tabId) {
      const worker = await ensureWorker(origin, { url: WORKER_URLS[origin] || `${origin}/` });
      tabId = worker.tabId;
      workers.set(origin, tabId);
    }
    const reply = await sendToTab(tabId, {
      type: "http",
      url: spec.url,
      method: spec.method || "GET",
      headers: spec.headers || {},
      body: spec.body == null ? null : String(spec.body),
      responseType: spec.responseType || "bytes"
    }, { tries: 8, timeoutMs: spec.timeoutMs || 45e3 });
    if (!reply || !reply.ok) {
      const err = new AppError(`\u9875\u9762\u5185\u8BF7\u6C42\u5931\u8D25\uFF1A${reply && reply.error || "\u65E0\u54CD\u5E94"}`, "BRIDGE_FAIL");
      err.bridgeStack = reply && reply.stack;
      throw err;
    }
    return {
      status: reply.status,
      url: reply.url || spec.url,
      headers: reply.headers || {},
      body: reply.bodyBase64 ? base64ToBytes(reply.bodyBase64) : new Uint8Array(0)
    };
  }
  async function bgRequest(spec) {
    const { url, method = "GET", headers = {}, body = null, timeoutMs = 45e3 } = spec;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(new DOMException("\u8BF7\u6C42\u8D85\u65F6", "TimeoutError")), timeoutMs);
    try {
      const res = await fetch(url, {
        method,
        headers,
        body: body == null ? void 0 : body,
        credentials: "include",
        redirect: "follow",
        cache: "no-store",
        signal: ctrl.signal
      });
      const buf = new Uint8Array(await res.arrayBuffer());
      const outHeaders = {};
      res.headers.forEach((value, key) => {
        outHeaders[key] = value;
      });
      return { status: res.status, url: res.url || url, headers: outHeaders, body: buf };
    } finally {
      clearTimeout(timer);
    }
  }
  function createBrowserTransport(settings = { transport: "auto" }) {
    const mode = settings.transport || "auto";
    const request = async (spec) => {
      const origin = originOf(spec.url);
      let bridgeErr = null;
      if (mode !== "bg" && origin) {
        try {
          return await bridgeRequest(spec);
        } catch (err) {
          bridgeErr = err;
          if (mode === "bridge") throw err;
          logEvent("warn", `\u6865\u63A5\u5931\u8D25\uFF0C\u6539\u7528\u540E\u53F0 fetch\uFF1A${err.message}`, {
            url: spec.url,
            ...err.bridgeStack ? { bridgeStack: String(err.bridgeStack).split("\n").slice(0, 4).join(" | ") } : {}
          });
        }
      }
      try {
        return await bgRequest(spec);
      } catch (err) {
        if (bridgeErr) {
          const message = isFirefox ? `\u8BF7\u6C42\u5931\u8D25\uFF08\u9875\u9762\u5185\u6865\u63A5\uFF1A${bridgeErr.message}\uFF1BFirefox \u4E0D\u5141\u8BB8\u6269\u5C55\u9875\u76F4\u63A5\u8BBF\u95EE http:// \u7AD9\u70B9\uFF0C\u8BF7\u5237\u65B0\u76EE\u6807\u9875\u9762\u540E\u91CD\u8BD5\uFF09` : `\u8BF7\u6C42\u5931\u8D25\uFF08\u6865\u63A5\uFF1A${bridgeErr.message}\uFF1B\u540E\u53F0\uFF1A${err.message}\uFF09`;
          throw new AppError(message, "REQUEST_FAIL");
        }
        throw err;
      }
    };
    return { request, mode };
  }
  async function probeViaTab(tabId, origin) {
    const started = Date.now();
    try {
      const reply = await sendToTab(tabId, {
        type: "http",
        url: `${origin}/`,
        method: "GET",
        headers: {},
        body: null,
        responseType: "text"
      }, { tries: 3, timeoutMs: 8e3 });
      if (!reply || !reply.ok) {
        return { ok: false, error: reply && reply.error || "\u65E0\u54CD\u5E94", ms: Date.now() - started, via: "bridge" };
      }
      return { ok: true, status: reply.status, ms: Date.now() - started, via: "bridge" };
    } catch (err) {
      return { ok: false, error: err && err.message || String(err), ms: Date.now() - started, via: "bridge" };
    }
  }
  async function probeOrigins() {
    const check = async (origin) => {
      if (isFirefox) {
        const worker = workers.get(origin);
        if (worker) return probeViaTab(worker, origin);
        const tabs = await findTabsByOrigin(origin);
        if (tabs.length) return probeViaTab(tabs[0].id, origin);
        return { ok: null, skipped: true, note: "Firefox \u9700\u5148\u6253\u5F00\u8BE5\u7AD9\u70B9\u9875\u9762\uFF0C\u6269\u5C55\u9875\u65E0\u6CD5\u76F4\u63A5\u8BBF\u95EE http:// \u7AD9\u70B9" };
      }
      const started = Date.now();
      try {
        const res = await bgRequest({ url: `${origin}/`, timeoutMs: 8e3 });
        return { ok: true, status: res.status, ms: Date.now() - started };
      } catch (err) {
        return { ok: false, error: err && err.message, ms: Date.now() - started };
      }
    };
    const [portal, reader] = await Promise.all([check(PORTAL_ORIGIN), check(READER_ORIGIN)]);
    return { portal, reader };
  }

  // src/background/downloads.js
  var offscreenCreating = null;
  async function hasOffscreenDocument() {
    if (!api.offscreen) return false;
    try {
      if (typeof api.offscreen.hasDocument === "function") return await api.offscreen.hasDocument();
    } catch {
    }
    return false;
  }
  async function ensureOffscreen() {
    if (isFirefox) return false;
    if (!api.offscreen) return false;
    const existing = await hasOffscreenDocument();
    if (existing && typeof api.offscreen.hasDocument === "function") return true;
    if (offscreenCreating) {
      await offscreenCreating.catch(() => {
      });
      return true;
    }
    offscreenCreating = (async () => {
      try {
        await api.offscreen.createDocument({
          url: "offscreen.html",
          reasons: ["BLOBS"],
          justification: "\u5728\u79BB\u7EBF\u6587\u6863\u91CC\u751F\u6210 PDF \u7684 blob URL\uFF0C\u4EA4\u7ED9\u4E0B\u8F7D\u63A5\u53E3"
        });
      } catch (err) {
        if (!/already|exists|single offscreen/i.test(String(err && err.message))) {
          logEvent("warn", `offscreen \u521B\u5EFA\u5931\u8D25\uFF1A${err && err.message}`);
        }
      }
    })();
    await offscreenCreating.catch(() => {
    });
    offscreenCreating = null;
    return true;
  }
  async function offscreenMakeUrl(bytes, mime) {
    await ensureOffscreen();
    const reply = await api.runtime.sendMessage({
      target: "offscreen",
      type: "make-url",
      mime,
      base64: bytesToBase64(bytes)
    });
    if (!reply || !reply.ok) throw new Error(reply && reply.error || "offscreen \u65E0\u54CD\u5E94");
    return reply;
  }
  async function offscreenRevoke(id) {
    try {
      await api.runtime.sendMessage({ target: "offscreen", type: "revoke", id });
    } catch {
    }
  }
  function dataUrl(bytes, mime) {
    return `data:${mime || "application/pdf"};base64,${bytesToBase64(bytes)}`;
  }
  async function saveBytes(bytes, filename, { saveAs = false, mime = "application/pdf" } = {}) {
    const name = filename || "document.pdf";
    let url = "";
    let via = "";
    let offscreenId = null;
    if (!isFirefox) {
      try {
        const made = await offscreenMakeUrl(bytes, mime);
        url = made.url;
        offscreenId = made.id;
        via = "offscreen";
      } catch (err) {
        logEvent("warn", `offscreen \u9020 URL \u5931\u8D25\uFF0C\u6362\u540E\u53F0\u9875\uFF1A${err.message}`);
      }
    }
    if (!url) {
      try {
        url = URL.createObjectURL(new Blob([bytes], { type: mime }));
        via = via || "blob";
        setTimeout(() => {
          try {
            URL.revokeObjectURL(url);
          } catch {
          }
        }, 18e4);
      } catch (err) {
        logEvent("warn", `blob URL \u5931\u8D25\uFF0C\u7528 data URL\uFF1A${err.message}`);
        url = dataUrl(bytes, mime);
        via = "data";
      }
    }
    const downloadId = await api.downloads.download({ url, filename: name, saveAs });
    if (offscreenId) {
      const cleanup = () => {
        offscreenRevoke(offscreenId);
        try {
          api.downloads.onChanged.removeListener(listener);
        } catch {
        }
        clearTimeout(timer);
      };
      const listener = (delta) => {
        if (delta && delta.id === downloadId && delta.state && (delta.state.current === "complete" || delta.state.current === "interrupted")) {
          cleanup();
        }
      };
      const timer = setTimeout(cleanup, 18e4);
      try {
        api.downloads.onChanged.addListener(listener);
      } catch {
        setTimeout(cleanup, 3e4);
      }
    }
    return { downloadId, filename: name, via };
  }

  // src/background/main.js
  var TASKS = /* @__PURE__ */ new Map();
  var taskSeq = 0;
  var hasSessionStorage = Boolean(api.storage && api.storage.session);
  var taskStore = hasSessionStorage ? api.storage.session : api.storage.local;
  var TASK_PREFIX = "task:";
  async function writeTaskRecord(task) {
    try {
      await taskStore.set({ [`${TASK_PREFIX}${task.id}`]: { ...task } });
    } catch (err) {
      logEvent("warn", `\u5199\u4EFB\u52A1\u72B6\u6001\u5931\u8D25\uFF1A${err.message}`);
    }
  }
  async function readTaskRecords() {
    try {
      const all = await taskStore.get(null);
      return Object.entries(all || {}).filter(([key]) => key.startsWith(TASK_PREFIX)).map(([, value]) => value).filter(Boolean);
    } catch {
      return [];
    }
  }
  function newTaskId() {
    return `t${Date.now().toString(36)}${(taskSeq++).toString(36)}`;
  }
  var HISTORY_KEY = "history";
  var HISTORY_LIMIT = 50;
  async function recordHistory(task) {
    try {
      const got = await api.storage.local.get(HISTORY_KEY);
      const list = Array.isArray(got[HISTORY_KEY]) ? got[HISTORY_KEY] : [];
      list.unshift({
        id: task.id,
        title: task.title || "",
        fid: task.fid || "",
        filename: task.filename || "",
        bytes: task.bytes || 0,
        pageCount: task.total || 0,
        status: task.status,
        error: task.error || null,
        endedAt: Date.now()
      });
      await api.storage.local.set({ [HISTORY_KEY]: list.slice(0, HISTORY_LIMIT) });
    } catch (err) {
      logEvent("warn", `\u5199\u4E0B\u8F7D\u5386\u53F2\u5931\u8D25\uFF1A${err.message}`);
    }
  }
  function makeHttp(settings, signal) {
    const { request } = createBrowserTransport(settings);
    return createHttp((spec) => {
      if (signal && signal.aborted) throw new AppError("\u5DF2\u53D6\u6D88", "CANCELLED");
      return request(spec);
    }, { retries: 2, timeoutMs: 6e4 });
  }
  async function updateTask(entry, patch, { silent = false } = {}) {
    Object.assign(entry.task, patch, { updatedAt: Date.now() });
    await writeTaskRecord(entry.task);
    if (silent) return;
    const message = { type: "task-update", task: { ...entry.task } };
    broadcast(message);
    if (entry.task.sourceTabId) {
      api.tabs.sendMessage(entry.task.sourceTabId, message).catch(() => {
      });
    }
  }
  async function clearReaderCookies() {
    try {
      const cookies = await api.cookies.getAll({ domain: "202.201.7.29" });
      for (const cookie of cookies || []) {
        const scheme = cookie.secure ? "https" : "http";
        const url = `${scheme}://${cookie.domain.replace(/^\./, "")}${cookie.path || "/"}`;
        await api.cookies.remove({ url, name: cookie.name });
      }
    } catch (err) {
      logEvent("warn", `\u6E05\u9605\u8BFB\u5668 cookie \u5931\u8D25\uFF1A${err.message}`);
    }
  }
  async function tabLooksGone(tabId) {
    try {
      const reply = await sendToTab(tabId, { type: "get-text" }, { tries: 3, timeoutMs: 4e3 });
      return GONE_RE.test(String(reply && reply.text || ""));
    } catch {
      return false;
    }
  }
  async function registerViaTab(token, { signal }) {
    const variants = [token, quoteToken(token)];
    const attempts = [...variants, ...variants];
    let lastErr = null;
    for (let i = 0; i < attempts.length; i++) {
      const url = `${READER_ORIGIN}${REGISTER_PATH}${attempts[i]}`;
      let tabId = null;
      try {
        tabId = await createHiddenTab(url);
        const { fid } = await waitForFid(tabId, { timeoutMs: 35e3, signal });
        await waitComplete(tabId, { timeoutMs: 2e4, signal }).catch(() => {
        });
        return { tabId, fid, created: true };
      } catch (err) {
        lastErr = err;
        const gone = tabId ? await tabLooksGone(tabId) : false;
        if (tabId) await closeTab(tabId);
        if (gone) {
          throw new AppError("\u8FD9\u4E2A\u4EE4\u724C\u5BF9\u5E94\u7684\u6587\u4EF6\u5DF2\u4E0D\u5B58\u5728\uFF0C\u6216\u4EE4\u724C\u5DF2\u8FC7\u671F\uFF08\u4EE4\u724C\u6709\u6548\u671F\u5F88\u77ED\uFF0C\u8BF7\u91CD\u65B0\u751F\u6210\uFF09\u3002", "GONE");
        }
        if (i >= variants.length - 1) await clearReaderCookies();
        await sleep(400 + 300 * (i % 2));
      }
    }
    throw lastErr instanceof Error ? lastErr : new AppError("\u6CE8\u518C\u5931\u8D25\uFF1A\u6CA1\u62FF\u5230 fid", "REGISTER_FAILED");
  }
  async function readMetaFromTab(tabId, fid) {
    let meta = null;
    try {
      const reply = await sendToTab(tabId, { type: "get-meta" }, { tries: 8, timeoutMs: 15e3 });
      meta = reply && reply.meta;
    } catch (err) {
      logEvent("warn", `\u9875\u9762\u811A\u672C\u53D6 meta \u5931\u8D25\uFF1A${err.message}`);
    }
    if (!meta || !pageCountOk(meta)) {
      try {
        const reply = await sendToTab(tabId, { type: "get-html" }, { tries: 4, timeoutMs: 8e3 });
        if (reply && reply.html) meta = parseMeta(reply.html);
      } catch {
      }
    }
    if (!meta || !pageCountOk(meta)) {
      try {
        const { meta: viaHttp } = await readMetaByHttp(fid);
        if (viaHttp && pageCountOk(viaHttp)) meta = viaHttp;
      } catch {
      }
    }
    return meta || {};
  }
  function pageCountOk(meta) {
    try {
      pageCount(meta);
      return true;
    } catch {
      return false;
    }
  }
  async function readMetaByHttp(fid) {
    const settings = await getSettings();
    const { request } = createBrowserTransport(settings);
    const http = createHttp(request, { retries: 1, timeoutMs: 3e4 });
    const html = await http.text(`${READER_ORIGIN}${INDEX_PATH}${encodeURIComponent(fid)}`);
    return { meta: parseMeta(html), html };
  }
  async function resolveTarget(spec, { signal }) {
    if (spec.fid && spec.pageTabId) {
      return {
        fid: String(spec.fid).toLowerCase(),
        meta: spec.meta || null,
        tabId: spec.pageTabId,
        created: false,
        fromPage: true
      };
    }
    if (spec.token) {
      const token = extractToken(spec.token) || String(spec.token);
      const { tabId, fid, created } = await registerViaTab(token, { signal });
      return { fid, tabId, created, meta: null };
    }
    if (spec.link) {
      const link = String(spec.link);
      if (link.includes("personaliiifServlet")) {
        const token = extractToken(link);
        if (!token) throw new AppError("\u94FE\u63A5\u91CC\u6CA1\u6709\u53EF\u7528\u7684\u4EE4\u724C\u3002", "NO_TOKEN");
        const { tabId: tabId2, fid, created } = await registerViaTab(token, { signal });
        return { fid, tabId: tabId2, created, meta: null };
      }
      const url = absoluteUrl(link, PORTAL_ORIGIN);
      const tabId = await createHiddenTab(url);
      try {
        const { fid } = await waitForFid(tabId, { timeoutMs: 35e3, signal });
        await waitComplete(tabId, { timeoutMs: 2e4, signal }).catch(() => {
        });
        const gone = await tabLooksGone(tabId);
        if (gone) throw new AppError("\u8FD9\u7BC7\u6587\u7AE0\u7684\u5168\u6587\u5DF2\u4E0B\u67B6\uFF0C\u6216\u5F53\u524D\u4F1A\u8BDD\u6CA1\u6709\u6743\u9650\u3002", "GONE");
        return { fid, tabId, created: true, meta: null };
      } catch (err) {
        await closeTab(tabId);
        throw err;
      }
    }
    if (spec.fid) {
      const fid = String(spec.fid).toLowerCase();
      if (!/^[0-9a-f]{32}$/.test(fid)) throw new AppError("fid \u5FC5\u987B\u662F 32 \u4F4D\u5341\u516D\u8FDB\u5236\u3002", "BAD_FID");
      const tabId = await createHiddenTab(`${READER_ORIGIN}${INDEX_PATH}${fid}`);
      try {
        await waitComplete(tabId, { timeoutMs: 3e4, signal });
        const gone = await tabLooksGone(tabId);
        if (gone) throw new AppError("\u8FD9\u4E2A fid \u5728\u5F53\u524D\u4F1A\u8BDD\u91CC\u6CA1\u6709\u6CE8\u518C\u8FC7\uFF0C\u6216\u6587\u4EF6\u5DF2\u4E0D\u5B58\u5728\u3002", "GONE");
        return { fid, tabId, created: true, meta: null };
      } catch (err) {
        await closeTab(tabId);
        throw err;
      }
    }
    throw new AppError("\u6CA1\u6709\u53EF\u7528\u7684\u8F93\u5165\uFF08\u4EE4\u724C / \u94FE\u63A5 / fid \u81F3\u5C11\u8981\u6709\u4E00\u4E2A\uFF09\u3002", "NO_INPUT");
  }
  function chooseTitle(meta, fid, settings) {
    const infoname = meta && meta.infoname;
    const filename = meta && meta.filename;
    const source = settings.filenameSource || "infoname";
    if (source === "filename" && filename) return filename.replace(/\.pdf$/i, "");
    if (source === "infoname" && infoname) return infoname;
    if (filename) return filename.replace(/\.pdf$/i, "");
    return titleOf(meta, fid);
  }
  async function runTask(entry, spec) {
    const { signal } = entry.ctrl;
    const http = makeHttp(await getSettings(), signal);
    let target = null;
    try {
      await updateTask(entry, { phase: "resolve", msg: "\u6B63\u5728\u6253\u5F00\u9605\u8BFB\u5668\u9875\u9762\u2026" });
      target = await resolveTarget(spec, { signal });
      entry.readerTab = target.tabId;
      setWorker(READER_ORIGIN, target.tabId);
      const meta = target.meta || await readMetaFromTab(target.tabId, target.fid);
      const total = pageCount(meta);
      const title = chooseTitle(meta, target.fid, await getSettings());
      await updateTask(entry, { fid: target.fid, title, total, phase: "urls", msg: `\u5171 ${total} \u9875\uFF0C\u51C6\u5907\u4E0B\u8F7D` });
      const result = await downloadDocument({
        http,
        fid: target.fid,
        meta: { ...meta, infoname: title },
        resolution: (await getSettings()).resolution,
        concurrency: (await getSettings()).concurrency,
        signal,
        onProgress: (p) => {
          updateTask(entry, {
            phase: p.phase,
            done: p.done,
            total: p.total,
            msg: p.msg || "",
            title: p.title || entry.task.title
          });
        }
      });
      await updateTask(entry, { phase: "save", msg: "\u4EA4\u7ED9\u6D4F\u89C8\u5668\u4E0B\u8F7D\u2026", total: result.pageCount });
      const settings = await getSettings();
      const saved = await saveBytes(result.pdf, result.filename, { saveAs: settings.saveAs });
      await updateTask(entry, {
        status: "done",
        phase: "done",
        done: result.pageCount,
        total: result.pageCount,
        filename: saved.filename,
        bytes: result.pdf.length,
        msg: `\u5DF2\u4FDD\u5B58 ${saved.filename}\uFF08${(result.pdf.length / 1024 / 1024).toFixed(1)} MB\uFF09`
      });
      await recordHistory(entry.task);
      logEvent("info", `\u4E0B\u8F7D\u5B8C\u6210\uFF1A${saved.filename}\uFF08${result.pageCount} \u9875\uFF0C${(result.pdf.length / 1024).toFixed(0)} KB\uFF0Cvia ${saved.via}\uFF09`);
    } catch (err) {
      const aborted = signal.aborted || err && err.code === "CANCELLED";
      const message = aborted ? "\u5DF2\u53D6\u6D88" : err && err.message || String(err);
      await updateTask(entry, {
        status: aborted ? "cancelled" : "error",
        phase: aborted ? "cancelled" : "error",
        error: message,
        errorCode: err && err.code || null
      });
      if (!aborted) {
        await recordHistory(entry.task);
        logEvent("error", `\u4EFB\u52A1\u5931\u8D25\uFF08${entry.task.title || entry.task.fid || "\u672A\u77E5\u6587\u6863"}\uFF09\uFF1A${message}`);
      }
    } finally {
      setWorker(READER_ORIGIN, null);
      const readerTab = entry.readerTab;
      if (readerTab && target && target.created) await closeTab(readerTab);
      setTimeout(() => TASKS.delete(entry.task.id), 15 * 60 * 1e3);
    }
  }
  async function startTask(spec) {
    const id = newTaskId();
    const entry = {
      task: {
        id,
        status: "running",
        phase: "queued",
        done: 0,
        total: 0,
        title: "",
        fid: String(spec.fid || "").toLowerCase(),
        filename: "",
        error: null,
        errorCode: null,
        msg: "",
        source: spec.source || (spec.pageTabId ? "page" : spec.token ? "token" : spec.link ? "link" : "fid"),
        sourceTabId: spec.sourceTabId ?? (spec.pageTabId || null),
        startedAt: Date.now(),
        updatedAt: Date.now()
      },
      ctrl: new AbortController(),
      readerTab: null
    };
    TASKS.set(id, entry);
    await updateTask(entry, {}, { silent: true });
    runTask(entry, spec).catch((err) => logEvent("error", `\u4EFB\u52A1\u7EBF\u7A0B\u5F02\u5E38\uFF1A${err && err.message}`));
    return entry.task;
  }
  function findTask(id) {
    const entry = TASKS.get(id);
    if (entry) return entry;
    return null;
  }
  async function withPortalWorker(fn) {
    const worker = await ensureWorker(PORTAL_ORIGIN, { url: SEARCH_URL });
    setWorker(PORTAL_ORIGIN, worker.tabId);
    try {
      const settings = await getSettings();
      return await fn(makeHttp(settings, null), worker);
    } finally {
      setWorker(PORTAL_ORIGIN, null);
      if (worker.created) await closeTab(worker.tabId);
    }
  }
  async function withPortalBatch(fn) {
    const worker = await ensureWorker(PORTAL_ORIGIN, { url: SEARCH_URL });
    setWorker(PORTAL_ORIGIN, worker.tabId);
    try {
      const settings = await getSettings();
      return await fn(makeHttp(settings, null), worker);
    } finally {
      setWorker(PORTAL_ORIGIN, null);
      if (worker.created) await closeTab(worker.tabId);
    }
  }
  async function doSearch(keyword) {
    const rows = await withPortalWorker((http) => search(http, keyword));
    await setLastKeyword(keyword);
    return rows;
  }
  async function doRecordLinks(record) {
    return withPortalWorker((http) => recordLinks(http, record));
  }
  async function resolveLinkToFid(link, { signal } = {}) {
    const target = await resolveTarget({ link }, { signal });
    const meta = target.meta || await readMetaFromTab(target.tabId, target.fid);
    let title = "";
    try {
      title = titleOf(meta, target.fid);
    } catch {
      title = "";
    }
    if (target.created) await closeTab(target.tabId);
    setWorker(READER_ORIGIN, null);
    return { fid: target.fid, meta, title };
  }
  async function handleMessage(message, sender) {
    const type = message && message.type;
    const settings = await getSettings();
    switch (type) {
      case "ping":
        return { ok: true, isFirefox, version: api.runtime.getManifest().version };
      case "probe": {
        const result = await probeOrigins();
        return { ok: true, ...result };
      }
      case "settings:get":
        return { ok: true, settings, lastKeyword: await getLastKeyword() };
      case "settings:set": {
        const next = await setSettings(message.patch || {});
        return { ok: true, settings: next };
      }
      case "log:get":
        return { ok: true, entries: await readLog().catch(() => []) };
      case "log:clear": {
        await clearLog().catch(() => {
        });
        return { ok: true };
      }
      case "history:get": {
        const got = await api.storage.local.get(HISTORY_KEY);
        return { ok: true, entries: Array.isArray(got[HISTORY_KEY]) ? got[HISTORY_KEY] : [] };
      }
      case "history:clear": {
        await api.storage.local.remove(HISTORY_KEY);
        return { ok: true };
      }
      case "open-app":
        await openAppPage(message.hash || "");
        return { ok: true };
      case "search": {
        const keyword = String(message.keyword || "").trim();
        if (!keyword) throw new AppError("\u8BF7\u8F93\u5165\u68C0\u7D22\u8BCD\u3002", "NO_KEYWORD");
        const result = await doSearch(keyword);
        enrichRowsInBackground(result.rows, sender, { resolveFid: settings.resolveFidOnSearch }).catch(() => {
        });
        return { ok: true, ...result, keyword };
      }
      case "record-links": {
        const found = await doRecordLinks(message.record);
        return { ok: true, links: found.links, absLinks: found.absLinks };
      }
      case "resolve-link": {
        const info = await resolveLinkToFid(message.link);
        return { ok: true, ...info };
      }
      case "start": {
        const spec = {
          token: message.token,
          link: message.link,
          fid: message.fid,
          pageTabId: message.pageTabId,
          meta: message.meta || null,
          sourceTabId: sender && sender.tab ? sender.tab.id : null
        };
        if (!spec.token && !spec.link && !spec.fid) {
          throw new AppError("\u6CA1\u6709\u53EF\u7528\u7684\u8F93\u5165\u3002", "NO_INPUT");
        }
        const task = await startTask(spec);
        return { ok: true, task };
      }
      case "start-from-page": {
        if (!sender || !sender.tab || sender.tab.id === void 0) {
          throw new AppError("\u53EA\u80FD\u4ECE\u9605\u8BFB\u5668\u9875\u9762\u91CC\u53D1\u8D77\u3002", "NOT_IN_PAGE");
        }
        const task = await startTask({
          fid: message.fid,
          meta: message.meta || null,
          pageTabId: sender.tab.id,
          source: "page"
        });
        return { ok: true, task };
      }
      case "cancel-task": {
        const entry = findTask(message.id);
        if (!entry) return { ok: false, error: "\u4EFB\u52A1\u4E0D\u5B58\u5728\u6216\u5DF2\u7ED3\u675F" };
        entry.ctrl.abort();
        return { ok: true };
      }
      case "get-task": {
        const entry = findTask(message.id);
        if (entry) return { ok: true, task: { ...entry.task } };
        const records = await readTaskRecords();
        const found = records.find((t) => t.id === message.id);
        return found ? { ok: true, task: found } : { ok: false, error: "\u4EFB\u52A1\u4E0D\u5B58\u5728" };
      }
      case "list-tasks": {
        const memory = Array.from(TASKS.values()).map((e) => ({ ...e.task }));
        const stored = await readTaskRecords();
        const byId = /* @__PURE__ */ new Map();
        for (const task of [...stored, ...memory]) byId.set(task.id, task);
        const list = Array.from(byId.values()).sort((a, b) => (b.startedAt || 0) - (a.startedAt || 0));
        return { ok: true, tasks: list.slice(0, 20) };
      }
      case "get-fid-info": {
        const token = extractToken(message.token || "");
        if (!token) throw new AppError("\u6CA1\u627E\u5230\u4EE4\u724C\u3002", "NO_TOKEN");
        return { ok: true, info: decodeToken(token) };
      }
      case "resolve-fids": {
        const rows = Array.isArray(message.rows) ? message.rows : [];
        enrichRowsInBackground(rows, sender, { resolveFid: true }).catch(() => {
        });
        return { ok: true, started: true };
      }
      default:
        return void 0;
    }
  }
  async function enrichRowsInBackground(rows, sender, opts = {}) {
    const list = (rows || []).filter((r) => r && r.id1 && r.id2);
    if (!list.length) return;
    const sourceTabId = sender && sender.tab ? sender.tab.id : null;
    const notify = (payload) => {
      broadcast(payload);
      if (sourceTabId) api.tabs.sendMessage(sourceTabId, payload).catch(() => {
      });
    };
    const pending = list.filter((r) => !r.link);
    if (pending.length) {
      try {
        await withPortalBatch(async (http) => {
          await mapPool(pending, 4, async (row) => {
            try {
              const found = await recordLinks(http, row);
              const link = found.absLinks && found.absLinks[0] || "";
              if (link) row.link = link;
              notify({ type: "row-link", id1: row.id1, id2: row.id2, link, title: row.title });
            } catch (err) {
              notify({ type: "row-link", id1: row.id1, id2: row.id2, link: "", error: err && err.message || String(err) });
            }
          });
        });
      } catch (err) {
        logEvent("warn", `\u8865\u5168\u5168\u6587\u94FE\u63A5\u5931\u8D25\uFF1A${err && err.message}`);
      }
    }
    if (opts.resolveFid) await resolveFidsInBackground(list, sender);
  }
  async function resolveFidsInBackground(rows, sender) {
    const list = (rows || []).filter((r) => r && r.link);
    if (!list.length) return;
    const sourceTabId = sender && sender.tab ? sender.tab.id : null;
    for (let i = 0; i < list.length; i++) {
      const row = list[i];
      let info = null;
      try {
        info = await resolveLinkToFid(row.link);
      } catch (err) {
        info = { fid: null, error: err && err.message };
      }
      const payload = {
        type: "row-fid",
        index: i,
        id1: row.id1,
        id2: row.id2,
        link: row.link,
        fid: info.fid || null,
        title: info.title || "",
        error: info.error || null
      };
      broadcast(payload);
      if (sourceTabId) api.tabs.sendMessage(sourceTabId, payload).catch(() => {
      });
      if (i < list.length - 1) await sleep(250);
    }
    broadcast({ type: "row-fid-done", count: list.length });
  }
  api.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message && message.target === "offscreen") return false;
    let promise;
    try {
      promise = handleMessage(message, sender);
    } catch (err) {
      sendResponse({ ok: false, error: err && err.message, code: err && err.code });
      return false;
    }
    if (!promise || typeof promise.then !== "function") {
      if (promise !== void 0) sendResponse(promise);
      return false;
    }
    promise.then((reply) => sendResponse(reply === void 0 ? { ok: false, error: "\u672A\u77E5\u6D88\u606F\u7C7B\u578B" } : reply)).catch((err) => sendResponse({ ok: false, error: err && err.message || String(err), code: err && err.code }));
    return true;
  });
  api.runtime.onInstalled.addListener((details) => {
    logEvent("info", `\u63D2\u4EF6${details.reason === "install" ? "\u5B89\u88C5" : details.reason === "update" ? "\u66F4\u65B0" : "\u542F\u7528"}\uFF08v${api.runtime.getManifest().version}\uFF09`);
    if (details.reason === "install") openAppPage("#/help").catch(() => {
    });
  });
  api.runtime.onStartup?.addListener(() => {
    recoverInterruptedTasks().catch(() => {
    });
  });
  async function recoverInterruptedTasks() {
    for (const task of await readTaskRecords()) {
      if (task.status === "running") {
        const patched = {
          ...task,
          status: "interrupted",
          phase: "interrupted",
          error: "\u540E\u53F0\u88AB\u6D4F\u89C8\u5668\u56DE\u6536\uFF0C\u4EFB\u52A1\u5DF2\u4E2D\u65AD\uFF0C\u8BF7\u91CD\u65B0\u4E0B\u8F7D\u3002",
          updatedAt: Date.now()
        };
        try {
          await taskStore.set({ [`${TASK_PREFIX}${task.id}`]: patched });
        } catch {
        }
      }
    }
  }
  recoverInterruptedTasks().catch(() => {
  });
  logEvent("info", `\u540E\u53F0\u5C31\u7EEA\uFF08${isFirefox ? "Firefox" : "Chrome"} v${api.runtime.getManifest().version}\uFF09`).catch(() => {
  });
})();
