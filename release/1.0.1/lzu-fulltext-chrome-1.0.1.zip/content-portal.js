(() => {
  // src/lib/protocol.js
  var PORTAL_ORIGIN = "http://202.201.7.17";
  var SEARCH_URL = PORTAL_ORIGIN + "/simpsearch.action?ffieldname=xkcode&ffieldkey=07*&dbid=72";
  var B64_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  function base64ToBytes(text) {
    const clean = String(text).replace(/[^A-Za-z0-9+/=]/g, "").replace(/=+$/, "");
    if (!clean) return new Uint8Array(0);
    const padded = clean + "=".repeat((4 - clean.length % 4) % 4);
    const bin = atob(padded);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function bytesToBase64(bytes) {
    const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const parts = [];
    let chunk = "";
    for (let i = 0; i < arr.length; i += 3) {
      const b0 = arr[i];
      const b1 = i + 1 < arr.length ? arr[i + 1] : 0;
      const b2 = i + 2 < arr.length ? arr[i + 2] : 0;
      chunk += B64_ALPHABET[b0 >> 2] + B64_ALPHABET[(b0 & 3) << 4 | b1 >> 4] + (i + 1 < arr.length ? B64_ALPHABET[(b1 & 15) << 2 | b2 >> 6] : "=") + (i + 2 < arr.length ? B64_ALPHABET[b2 & 63] : "=");
      if (chunk.length >= 32768) {
        parts.push(chunk);
        chunk = "";
      }
    }
    if (chunk) parts.push(chunk);
    return parts.join("");
  }
  function unquote(text) {
    const src = String(text);
    const bytes = [];
    for (let i = 0; i < src.length; i++) {
      const ch = src[i];
      if (ch === "%" && /^[0-9a-fA-F]{2}$/.test(src.slice(i + 1, i + 3))) {
        bytes.push(parseInt(src.slice(i + 1, i + 3), 16));
        i += 2;
      } else {
        const code = src.charCodeAt(i);
        if (code < 128) {
          bytes.push(code);
        } else {
          for (const b of new TextEncoder().encode(src[i])) bytes.push(b);
        }
      }
    }
    return new TextDecoder("utf-8", { fatal: false }).decode(new Uint8Array(bytes));
  }
  function decodeToken(token) {
    const raw = String(token || "").trim();
    if (raw.length < 6) throw new Error("\u4EE4\u724C\u592A\u77ED\uFF0C\u65E0\u6CD5\u89E3\u6790");
    const prefix = raw.slice(0, 5);
    const body = raw.slice(5).replace(/%3[dD]/g, "=");
    let payload;
    try {
      payload = new TextDecoder("utf-8", { fatal: false }).decode(base64ToBytes(body));
    } catch (err) {
      throw new Error(`\u4EE4\u724C base64 \u89E3\u7801\u5931\u8D25\uFF1A${err.message}`);
    }
    const parts = payload.split("&");
    const path = unquote(parts.shift() || "");
    const fields = /* @__PURE__ */ Object.create(null);
    for (const kv of parts) {
      const idx = kv.indexOf("=");
      if (idx > 0) fields[kv.slice(0, idx)] = unquote(kv.slice(idx + 1));
    }
    const num = (v) => {
      const n = Number.parseInt(v, 10);
      return Number.isFinite(n) ? n : null;
    };
    const storeName = path.split(/[\\/]/).pop() || path;
    return {
      prefix,
      path,
      storeName,
      startpage: num(fields.startpage),
      endpage: num(fields.endpage),
      down: num(fields.down),
      watermark: fields.watermark || "",
      filename: fields.filename || "",
      infoname: fields.infoname || "",
      fields: Object.freeze({ ...fields })
    };
  }

  // src/lib/ext.js
  var api = globalThis.browser ?? globalThis.chrome;
  var navUserAgent = (() => {
    try {
      return String(typeof navigator !== "undefined" && navigator.userAgent || "");
    } catch {
      return "";
    }
  })();
  var isFirefox = typeof (api && api.runtime && api.runtime.getBrowserInfo) === "function" || navUserAgent.includes("Firefox/");

  // src/lib/reader.js
  var META_FIELDS = [
    "fid",
    "sum",
    "pageCount",
    "startpage",
    "endpage",
    "filename",
    "infoname",
    "watermark",
    "pdfchange",
    "pagewidth",
    "pageheight"
  ];
  var NULLISH = /* @__PURE__ */ new Set(["", "null", "NULL", "Null", "undefined"]);
  var escapeRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  function hiddenValue(html, name) {
    const n = escapeRe(name);
    const patterns = [
      new RegExp(`id="${n}"[^>]*?value="([^"]*)"`),
      new RegExp(`value="([^"]*)"[^>]*?id="${n}"`),
      new RegExp(`name="${n}"[^>]*?value="([^"]*)"`),
      new RegExp(`value="([^"]*)"[^>]*?name="${n}"`)
    ];
    const src = String(html || "");
    for (const re of patterns) {
      const m = re.exec(src);
      if (m && !NULLISH.has(m[1])) return m[1];
    }
    return null;
  }
  function parseMeta(html) {
    const meta = {};
    for (const key of META_FIELDS) meta[key] = hiddenValue(html, key);
    return meta;
  }
  function fidFromHtml(html) {
    const v = hiddenValue(html, "fid");
    if (v && /^[0-9a-fA-F]{32}$/.test(v)) return v.toLowerCase();
    const m = /\bfid=([0-9a-fA-F]{32})/.exec(String(html || ""));
    return m ? m[1].toLowerCase() : null;
  }

  // src/content/bridge.js
  async function doFetch(spec) {
    try {
      const res = await fetch(spec.url, {
        method: spec.method || "GET",
        headers: spec.headers || {},
        body: spec.body == null ? void 0 : spec.body,
        credentials: "include",
        redirect: "follow",
        cache: "no-store"
      });
      const body = new Uint8Array(await res.arrayBuffer());
      const headers = {};
      res.headers.forEach((value, key) => {
        headers[key] = value;
      });
      return {
        ok: true,
        status: res.status,
        url: res.url || spec.url,
        headers,
        bodyBase64: bytesToBase64(body)
      };
    } catch (err) {
      return {
        ok: false,
        error: String(err && err.message || err),
        stack: String(err && err.stack || "")
      };
    }
  }
  function pageHtml() {
    return document.documentElement ? document.documentElement.outerHTML : "";
  }
  function pageText() {
    return document.body ? document.body.innerText || "" : "";
  }
  function readPageMeta() {
    return parseMeta(pageHtml());
  }
  function readPageFid() {
    return fidFromHtml(pageHtml()) || fidFromUrlSafe(location.href);
  }
  function fidFromUrlSafe(url) {
    const m = /\bfid=([0-9a-fA-F]{32})/.exec(String(url || ""));
    return m ? m[1].toLowerCase() : null;
  }
  function installBridge() {
    if (window.__lzuBridgeInstalled) return false;
    window.__lzuBridgeInstalled = true;
    api.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || typeof message.type !== "string") return false;
      switch (message.type) {
        case "ping":
          sendResponse({ ok: true, url: location.href });
          return false;
        case "http":
          doFetch(message).then(sendResponse);
          return true;
        case "get-html":
          sendResponse({ ok: true, html: pageHtml(), url: location.href });
          return false;
        case "get-text":
          sendResponse({ ok: true, text: pageText(), url: location.href });
          return false;
        case "get-meta":
          sendResponse({ ok: true, meta: readPageMeta(), fid: readPageFid(), url: location.href });
          return false;
        case "get-links": {
          const links = Array.from(document.querySelectorAll("a[href]")).map((a) => a.getAttribute("href")).filter((href) => href && /onlinePDF/i.test(href));
          sendResponse({ ok: true, links });
          return false;
        }
        default:
          return false;
      }
    });
    return true;
  }

  // src/content/panel.js
  var STYLE = `
  :host { all: initial; }
  .card {
    position: fixed; right: 18px; bottom: 18px; z-index: 2147483647;
    width: 300px; box-sizing: border-box;
    font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC",
          "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
    color: #1f2937; background: #fff;
    border: 1px solid #dbe3ef; border-radius: 12px;
    box-shadow: 0 12px 32px rgba(15, 23, 42, .18);
    overflow: hidden;
  }
  .head {
    display: flex; align-items: center; gap: 8px;
    padding: 10px 12px; color: #fff;
    background: linear-gradient(135deg, #1d4ed8, #2563eb 55%, #3b82f6);
  }
  .head .logo {
    width: 18px; height: 18px; border-radius: 5px; background: rgba(255,255,255,.22);
    display: inline-flex; align-items: center; justify-content: center; font-size: 11px;
  }
  .head .name { font-weight: 600; font-size: 13px; flex: 1; }
  .head button {
    all: unset; cursor: pointer; color: rgba(255,255,255,.85);
    font-size: 15px; line-height: 1; padding: 2px 4px; border-radius: 5px;
  }
  .head button:hover { background: rgba(255,255,255,.18); color: #fff; }
  .body { padding: 10px 12px 12px; display: flex; flex-direction: column; gap: 8px; }
  .title {
    font-size: 12.5px; font-weight: 600; color: #111827;
    display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
  }
  .sub { font-size: 11.5px; color: #6b7280; word-break: break-all; }
  .bar { height: 5px; border-radius: 999px; background: #eef2f7; overflow: hidden; }
  .bar > i { display: block; height: 100%; width: 0%; background: #2563eb; transition: width .2s; }
  .status { font-size: 11.5px; color: #4b5563; min-height: 16px; }
  .status.error { color: #b91c1c; }
  .status.done { color: #047857; }
  .row { display: flex; gap: 8px; flex-wrap: wrap; }
  button.act {
    all: unset; cursor: pointer; box-sizing: border-box;
    padding: 6px 12px; border-radius: 8px; font-size: 12.5px; font-weight: 600;
    border: 1px solid #d6dde9; color: #1f2937; background: #f8fafc;
  }
  button.act:hover { background: #eef2f7; }
  button.act.primary {
    border-color: #1d4ed8; color: #fff;
    background: linear-gradient(135deg, #1d4ed8, #3b82f6);
  }
  button.act.primary:hover { filter: brightness(1.05); }
  button.act[disabled] { opacity: .55; cursor: not-allowed; }
  .list { display: flex; flex-direction: column; gap: 6px; max-height: 168px; overflow: auto; }
  .list a { color: #1d4ed8; text-decoration: none; font-size: 12px; }
  .list a:hover { text-decoration: underline; }
  .hidden { display: none !important; }
`;
  var PHASE_TEXT = {
    queued: "\u6392\u961F\u4E2D\u2026",
    resolve: "\u6B63\u5728\u6253\u5F00\u9605\u8BFB\u5668\u2026",
    meta: "\u8BFB\u53D6\u6587\u6863\u4FE1\u606F\u2026",
    urls: "\u83B7\u53D6\u9875\u9762\u5730\u5740\u2026",
    pages: "\u4E0B\u8F7D\u9875\u9762\u2026",
    build: "\u5408\u6210 PDF\u2026",
    save: "\u4FDD\u5B58\u6587\u4EF6\u2026",
    done: "\u5DF2\u4FDD\u5B58",
    error: "\u5931\u8D25",
    cancelled: "\u5DF2\u53D6\u6D88",
    interrupted: "\u5DF2\u4E2D\u65AD"
  };
  function createPanel(opts = {}) {
    const host = document.createElement("div");
    host.id = "lzu-thesis-helper-host";
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = STYLE;
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
    <div class="head">
      <span class="logo">L</span>
      <span class="name">\u5170\u5927\u8BBA\u6587\u5168\u6587\u52A9\u624B</span>
      <button class="close" title="\u6536\u8D77">\u2715</button>
    </div>
    <div class="body">
      <div class="title"></div>
      <div class="sub hidden"></div>
      <div class="bar hidden"><i></i></div>
      <div class="status"></div>
      <div class="row actions"></div>
    </div>`;
    shadow.appendChild(style);
    shadow.appendChild(card);
    const $ = (sel) => card.querySelector(sel);
    const titleEl = $(".title");
    const subEl = $(".sub");
    const barEl = $(".bar");
    const barFill = $(".bar > i");
    const statusEl = $(".status");
    const actionsEl = $(".actions");
    const closeEl = $(".close");
    const actionButtons = /* @__PURE__ */ new Map();
    const state = { busy: false };
    function setTitle(text) {
      titleEl.textContent = text || "";
      titleEl.classList.toggle("hidden", !text);
    }
    function setSubtitle(text) {
      subEl.textContent = text || "";
      subEl.classList.toggle("hidden", !text);
    }
    function setStatus(text, kind = "") {
      statusEl.textContent = text || "";
      statusEl.className = `status ${kind}`.trim();
    }
    function setProgress(done, total) {
      const show = Number.isFinite(done) && Number.isFinite(total) && total > 0;
      barEl.classList.toggle("hidden", !show);
      if (show) barFill.style.width = `${Math.max(0, Math.min(100, done / total * 100)).toFixed(1)}%`;
    }
    function setBusy(busy) {
      state.busy = busy;
      for (const [id, btn] of actionButtons) {
        if (id === "workspace" || id === "help") continue;
        btn.disabled = busy;
      }
    }
    function setActions(actions = []) {
      actionsEl.textContent = "";
      actionButtons.clear();
      for (const action of actions) {
        const btn = document.createElement("button");
        btn.className = `act${action.primary ? " primary" : ""}`;
        btn.textContent = action.label;
        btn.addEventListener("click", () => {
          if (state.busy && action.primary) return;
          if (opts.onAction) opts.onAction(action.id);
        });
        actionsEl.appendChild(btn);
        actionButtons.set(action.id, btn);
      }
    }
    function applyTask(task) {
      if (!task) return;
      if (task.title) setTitle(task.title);
      if (task.total) setSubtitle(`${task.total} \u9875${task.fid ? ` \xB7 ${task.fid.slice(0, 8)}\u2026` : ""}`);
      setProgress(task.done, task.total);
      const phase = PHASE_TEXT[task.phase] || PHASE_TEXT[task.status] || "";
      if (task.status === "done") {
        setBusy(false);
        setStatus(`\u2713 ${task.msg || `\u5DF2\u4FDD\u5B58 ${task.filename || ""}`}`, "done");
      } else if (task.status === "error") {
        setBusy(false);
        setStatus(`\u2717 ${task.error || "\u4E0B\u8F7D\u5931\u8D25"}`, "error");
      } else if (task.status === "cancelled" || task.status === "interrupted") {
        setBusy(false);
        setStatus(task.status === "cancelled" ? "\u5DF2\u53D6\u6D88" : task.error || "\u4EFB\u52A1\u5DF2\u4E2D\u65AD", "error");
      } else {
        setBusy(true);
        setStatus(task.msg || phase);
      }
    }
    closeEl.addEventListener("click", () => {
      if (opts.onClose) opts.onClose();
      else host.remove();
    });
    setTitle(opts.title || "");
    if (opts.subtitle) setSubtitle(opts.subtitle);
    else subEl.classList.add("hidden");
    setActions(opts.actions || []);
    (document.body || document.documentElement).appendChild(host);
    return {
      host,
      setTitle,
      setSubtitle,
      setStatus,
      setProgress,
      setBusy,
      setActions,
      applyTask,
      remove: () => host.remove()
    };
  }

  // src/content/portal.js
  installBridge();
  var panel = null;
  var currentTaskId = null;
  function collectLinks() {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const a of Array.from(document.querySelectorAll("a[href]"))) {
      const href = a.getAttribute("href") || "";
      if (!/onlinePDF/i.test(href)) continue;
      const abs = toAbsolute(href);
      if (!abs || seen.has(abs)) continue;
      seen.add(abs);
      out.push(abs);
    }
    return out;
  }
  function toAbsolute(href) {
    try {
      return new URL(href, location.href).href;
    } catch {
      return "";
    }
  }
  function describe(link) {
    const objid = /[?&]objid=([^&]+)/.exec(link);
    const token = /personaliiifServlet\?path=([A-Za-z0-9+/=%]+)/.exec(link);
    if (token) {
      try {
        const info = decodeToken(token[1]);
        return info.infoname || info.filename || "";
      } catch {
        return "";
      }
    }
    return objid ? `objid ${objid[1]}` : "";
  }
  function init() {
    const links = collectLinks();
    if (!links.length) return;
    const actions = links.map((link, i) => ({
      id: `link:${i}`,
      label: links.length > 1 ? `\u4E0B\u8F7D\u7B2C ${i + 1} \u7BC7` : "\u4E0B\u8F7D\u5168\u6587",
      primary: i === 0
    }));
    actions.push({ id: "workspace", label: "\u5DE5\u4F5C\u53F0" });
    panel = createPanel({
      title: links.length > 1 ? `\u53D1\u73B0 ${links.length} \u7BC7\u53EF\u4E0B\u8F7D\u5168\u6587` : "\u53D1\u73B0\u53EF\u4E0B\u8F7D\u7684\u5168\u6587",
      subtitle: describe(links[0]) || "\u70B9\u51FB\u4E0B\u65B9\u6309\u94AE\u5F00\u59CB\uFF08\u7EA6\u6309\u9875\u6570\u8017\u65F6\uFF09",
      actions,
      onAction: (id) => onAction(id, links)
    });
    panel.setStatus("PDF \u4E3A\u9605\u8BFB\u5668\u6E32\u67D3\u7684\u56FE\u7247\u9875\uFF0C\u4E0D\u542B\u6587\u5B57\u5C42");
    api.runtime.onMessage.addListener((message) => {
      if (!message || message.type !== "task-update" || !message.task || !panel) return false;
      if (!currentTaskId || message.task.id !== currentTaskId) return false;
      panel.applyTask(message.task);
      if (message.task.status !== "running") {
        currentTaskId = null;
        panel.setActions(actions);
      }
      return false;
    });
  }
  async function onAction(id, links) {
    if (!panel) return;
    if (id === "workspace") {
      await api.runtime.sendMessage({ type: "open-app", hash: "#/workspace" }).catch(() => {
      });
      return;
    }
    const match = /^link:(\d+)$/.exec(id);
    if (!match) return;
    const link = links[Number(match[1])];
    if (!link) return;
    panel.setBusy(true);
    panel.setStatus("\u6B63\u5728\u6253\u5F00\u5168\u6587\u5165\u53E3\u2026");
    panel.setActions([{ id: "workspace", label: "\u5DE5\u4F5C\u53F0" }]);
    try {
      const reply = await api.runtime.sendMessage({ type: "start", link });
      if (!reply || !reply.ok) throw new Error(reply && reply.error || "\u540E\u53F0\u6CA1\u6709\u54CD\u5E94");
      currentTaskId = reply.task.id;
      panel.applyTask(reply.task);
    } catch (err) {
      panel.setBusy(false);
      panel.setStatus(`\u2717 ${err.message || err}`, "error");
      panel.setActions(links.map((l, i) => ({ id: `link:${i}`, label: links.length > 1 ? `\u7B2C ${i + 1} \u7BC7` : "\u91CD\u8BD5", primary: i === 0 })).concat([{ id: "workspace", label: "\u5DE5\u4F5C\u53F0" }]));
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      try {
        init();
      } catch (err) {
        console.warn("[\u5170\u5927\u5168\u6587\u52A9\u624B] \u521D\u59CB\u5316\u5931\u8D25", err);
      }
    }, { once: true });
  } else {
    try {
      init();
    } catch (err) {
      console.warn("[\u5170\u5927\u5168\u6587\u52A9\u624B] \u521D\u59CB\u5316\u5931\u8D25", err);
    }
  }
})();
